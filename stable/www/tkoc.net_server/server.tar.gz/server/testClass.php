<?php
/* Server.php
 *
 * Handles server updates each tick.  This script *must* be called each tick...
 */
//die("ENDED");
require_once ("/home/prosjekt/tkoc.net/scripts/Database.class.inc.php");
require_once ("/home/prosjekt/tkoc.net/scripts/all.inc.php");
require_once ("/home/prosjekt/tkoc.net/scripts/Magic.class.inc.php");
require_once ("/home/prosjekt/server/config.server.php");
require_once ("/home/prosjekt/server/Server.class.inc.php");

$database = new Database($DBLOGIN,$DBPASSW,$DBHOST,$DBDATABASE);
$database->connect();

// Magic class
$dummy = NULL;
$magic = new Magic(&$database,$dummy);
$magic->doTick();

$database->shutdown();
?>

