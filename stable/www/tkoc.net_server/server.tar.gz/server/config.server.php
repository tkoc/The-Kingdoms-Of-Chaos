<?php
// do not modify!  Computer generated code below!
// (modified by script)
$config["ticks"] = 456;

?>
