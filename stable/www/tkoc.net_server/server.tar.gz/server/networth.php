<?php
require_once("/home/chaos/www/scripts/globals.inc.php");
$GLOBALS['script_mode'] = 'server'; // override the web mode.
require_once ($GLOBALS['path_www_scripts'] . "all.inc.php");
require_once ($GLOBALS['path_www_scripts'] . "Province.class.inc.php");

$db = $GLOBALS['database'];
$db->query("SELECT pID from Province");

while (($res = $db->fetchArray()))
{
	$province = new Province($res['pID'],$GLOBALS['database']);
	$province->getProvinceData();
//	echo "(OLD)Province: " . $province->provinceName . " : " . $province->networth  . "\n";
	$province->setNetworth();
//	echo "(NEW)Province: " . $province->provinceName . " : " . $province->networth  . "\n";
}
?>
