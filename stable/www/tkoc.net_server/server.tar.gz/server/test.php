<?php
require_once ("/home/chaos/www/scripts/Database.class.inc.php");
require_once ("/home/chaos/www/scripts/all.inc.php");

$database = new Database($DBLOGIN,$DBPASSW,$DBHOST,$DBDATABASE);
$database->connect();

$database->query("SELECT * from Config");
$config = $database->fetchArray();

require_once("/home/chaos/www/administration/RecruitPlayers.class.inc.php");

echo "creating object:\n";
$recruit = new RecruitPlayers($database);

echo "giving bonus to 3039, 1 is signup.\n";
$recruit->doTick();
echo "done\n";
?>
