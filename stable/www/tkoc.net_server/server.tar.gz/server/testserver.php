<?php
//die();
//************************************************
//* server.php
//*
//* The game engine.  This should be run every tick
//* Author: Anders Elton
//*
//* History:
//*	- Rewrite 31.07.2004
//************************************************
// TODO:  writeLog function, writeErr function
//die("this is fucked up");


require_once("/home/chaos/www/scripts/globals.inc.php");
$GLOBALS['script_mode'] = 'server'; // override the web mode.

require_once ($GLOBALS['path_www_scripts'] . "Database.class.inc.php");
require_once ($GLOBALS['path_www_scripts'] . "all.inc.php");
require_once ($GLOBALS['path_www_scripts'] . "Kingdom.class.inc.php");
require_once ($GLOBALS['path_www_scripts'] . "TrigEffect.class.inc.php");
require_once ($GLOBALS['path_www_scripts'] . "seasons/SeasonFactory.class.inc.php");
require_once ($GLOBALS['path_server'] . "Server.class.inc.php");
require_once ($GLOBALS['path_server'] . "ServerStatistics.class.inc.php");

$database = $GLOBALS['database'];
$config = $GLOBALS['config'];
$start = $GLOBALS['game_start_clock'];

$server = new Server(&$database);
$server->removeResetProvince();
$server->fixBrokenUsers();
$server->fixBrokenProvinces();
$server->prepareTick();

echo "Kingdom\n";
$kingdom = new Kingdom($database);
$kingdom->doTick();

echo "Server\n";
// server class
$server->doTick();

?>
