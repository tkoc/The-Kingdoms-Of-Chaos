<?php
die("EDIT TO SEND!!!");
require_once ("/home/chaos/www/scripts/all.inc.php");
require_once ("/home/chaos/www/scripts/Database.class.inc.php");
// sending mass mail to all users

$msg = 'A New Age in The Kingdom of Chaos is Online!

Age '.$GLOBALS['config']['age'].' has just been placed online for registration.

To view the most recent changes please go to the forum and look in the announcement forum.
http://www.tkoc.net/scripts/forum.php?forumID=5
                        
We hope to see you again for a new exciting age
Regards,
         
Chaos Admins.
';

// do not edit below!!!
$subject = "The Kingdoms of Chaos";
$mailheaders = "From: Chaos Admin <admin@tkoc.net> \n";
$mailheaders .= "Reply-To: admin@tkoc.net\n\n";

// set up database
$database = new Database($DBLOGIN,$DBPASSW,$DBHOST,$DBDATABASE);
if ($database->connect()) {
  $num =0;
  $database->query("SELECT * From User where status='Active'");
  while ($database->numRows() && ($usr=$database->fetchArray())) {
	$num++;
	$message =  "Dear $usr[name]\n\n" . $msg;
//echo $message;
        $mail = $usr['email'];
        mail($mail, $subject, $message, $mailheaders);
	echo "sending mail ($num)\n";
  }

} else die ("DATABASE ERROR!");


$database->shutdown();
?>
