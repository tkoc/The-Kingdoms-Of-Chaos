<?php
require_once("/home/chaos/www/scripts/globals.inc.php");
$GLOBALS['script_mode'] = 'server'; // override the web mode.
require_once ($GLOBALS['path_www_scripts'] . "all.inc.php");
require_once ($GLOBALS['path_www_hero'] .    "Hero.class.inc.php");

$hero = new Hero($GLOBALS['database']);
$hero->DoTick();

?>
