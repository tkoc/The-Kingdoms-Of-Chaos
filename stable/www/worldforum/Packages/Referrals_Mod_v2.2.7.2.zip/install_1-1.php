<?php
/*****************************************
* Fustrate - Referrals Mod - install.php *
*****************************************/

if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
else if(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php and SSI.php files.');

if((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin priveleges required.');

// Adds the new columns to the members table - first checks if the column exists, if it doesnt, it adds it
$newcolumns['referrals_no'] = array('referralsno', "mediumint(8) NOT NULL default '0'");
$newcolumns['referrals_hits'] = array('referralshits', "mediumint(10) NOT NULL default '0'");
$newcolumns['referred_by'] = array('referredby', "mediumint(8) NOT NULL default '0'");
$newcolumns['referred_on'] = array('referredon', "int(10) NOT NULL default '0'");

foreach($newcolumns as $column => $spec){	
	// Old type, so rename
	$result = db_query("
		SHOW COLUMNS
		FROM {$db_prefix}members
		LIKE '{$spec[0]}'", __FILE__, __LINE__);

	if (mysql_num_rows($result) > 0)	
		db_query("
			ALTER TABLE {$db_prefix}members
			CHANGE {$spec[0]} {$column} {$spec[1]}", __FILE__, __LINE__);
	else {
		// Check if already have the new type
		$result = db_query("
			SHOW COLUMNS
			FROM {$db_prefix}members
			LIKE '$column'", __FILE__, __LINE__);
	
		// No previous install so create it
		if (mysql_num_rows($result) == 0)
			db_query("
				ALTER TABLE {$db_prefix}members
				ADD COLUMN $column {$spec[1]}", __FILE__, __LINE__);
	}

	mysql_free_result($result);
}

// Log Activity column
$result = db_query("
	SHOW COLUMNS
	FROM {$db_prefix}log_activity
	LIKE 'referrals'", __FILE__, __LINE__);

if (mysql_num_rows($result) == 0)	
	db_query("
		ALTER TABLE {$db_prefix}log_activity
		ADD COLUMN referrals int(8) NOT NULL default '0'", __FILE__, __LINE__);

mysql_free_result($result);

if(SMF == 'SSI')
	echo 'Database changes are complete!';

?>