<?php
/**********************************************************************************
* add_settings.php                                                                *
***********************************************************************************
* Modification by:            Jason Clemons (http://gamingbrotherhood.com)        *
* Copyright 2009 by:          Socialite Development (http://socialiteproject.com) *
***********************************************************************************
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
**********************************************************************************/

/*	This file is a simplified database installer. It does what it is suppoed to. */

// List settings here in the format: setting_key => default_value.  Escape any "s. (" => \")
//$mod_settings = array();

// Settings to create the new tables...
//$tables = array();

// Insert new row data
//$rows = array();

// Create some new columns
$columns = array();
$columns[] = array(
	'table_name' => '{db_prefix}members',
	'column_info' => array(
		'name' => 'referrals_no',
		'type' => 'mediumint',
		'size' => 8,
		'null' => false,
		'default' => '0',
	),
	'if_exists' => 'update',
	'error' => 'fatal',
);

$columns[] = array(
	'table_name' => '{db_prefix}members',
	'column_info' => array(
		'name' => 'referrals_hits',
		'type' => 'mediumint',
		'size' => 10,
		'null' => false,
		'default' => '0',
	),
	'if_exists' => 'update',
	'error' => 'fatal',
);

$columns[] = array(
	'table_name' => '{db_prefix}members',
	'column_info' => array(
		'name' => 'referred_by',
		'type' => 'mediumint',
		'size' => 8,
		'null' => false,
		'default' => '0',
	),
	'if_exists' => 'update',
	'error' => 'fatal',
);

$columns[] = array(
	'table_name' => '{db_prefix}members',
	'column_info' => array(
		'name' => 'referred_on',
		'type' => 'int',
		'size' => 8,
		'null' => false,
		'default' => '0',
	),
	'if_exists' => 'update',
	'error' => 'fatal',
);

$columns[] = array(
	'table_name' => '{db_prefix}log_activity',
	'column_info' => array(
		'name' => 'referrals',
		'type' => 'int',
		'size' => 8,
		'null' => false,
		'default' => '0',
	),
	'if_exists' => 'update',
	'error' => 'fatal',
);

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this file in the same place as SMF\'s SSI.php.');

if (!empty($mod_settings))
	updateSettings($mod_settings); 
if (!empty($tables)) {
	foreach ($tables as $table)
		$smcFunc['db_create_table']($table['table_name'], $table['columns'], $table['indexes'], $table['parameters'], $table['if_exists'], $table['error']);
}
if (!empty($rows)) {
	foreach ($rows as $row)
		$smcFunc['db_insert']($row['method'], $row['table_name'], $row['columns'], $row['data'], $row['keys']);
}
if (!empty($columns)) {			
	foreach ($columns as $column)
		$smcFunc['db_add_column']($column['table_name'], $column['column_info'], $column['parameters'], $column['if_exists'], $column['error']);
}

if (SMF == 'SSI')
	echo 'Congratulations! You have successfully installed Referrals Mod!';

?>