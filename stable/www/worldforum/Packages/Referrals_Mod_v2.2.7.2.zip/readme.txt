[hr]
[center][color=red][size=16pt][b]Referrals Mod v2.2.7.2[/b][/size][/color][/center]
[hr]

[[url=http://custom.simplemachines.org/mods/index.php?mod=1114]Link to Mod[/url]] [[url=http://www.simplemachines.org/community/index.php?topic=226191]Support and Comments[/url]]

[b][color=blue]Introduction[/color][/b]
A simpe modification for members to refer new members and see who referred who. Modification versions 2.0 and below made by karlbenson, all later development by YodaOfDarkness.

[b][color=blue]Features[/color][/b]
o Adds a referral link to each users profile area 
 :: http://www.jblaze.net/forum/index.php?action=register;referredby=1 - where 1 is the user ID
o Users can then paste the link to whoever they want to invite - suitable for email, signatures, messengers, webpages, forums etc
o When a guest/visitor uses the referral link a 'tracking' cookie is placed on their computer, so they can browse away from the link and register on your forum up to 60 days later (unless cookies are deleted) with the referral credited to the referring user.
o If no referral cookie is found, prospective members can type in a name to be their referral
o Adds 2 Referral stats section showing;
 :: Top 5 Referrers (By Referrals)
 :: Top 5 Referrers (By Referred Members Posts)
 :: Daily/Monthly/Yearly Referrals Stats
o Total Referrals of each user shown in the poster information of each post
o Referrals information shown in Profile Summary
 ::  Shows referral link in profile
 ::  Shows number of referrals
 ::  Dropdown showing each member user has referred (Linked to the members profile pages)
 ::  Referral Hits (a.k.a number of clicks on your referral link)
o Referred member information also shown in Profile Summary
 ::  If user was referred, shows the user who referred them and the original date of referral

[b][color=blue]Support[/color][/b]
Please use the modification thread for support with this modification. Personal messages for support are discouraged.

[b][color=blue]Languages[/color][/b]
[img]http://www.simplemachines.org/site_images/lang/english.gif[/img] [img]http://www.simplemachines.org/site_images/lang/english_british.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/portuguese_pt.gif[/img] [img]http://www.simplemachines.org/site_images/lang/arabic.gif[/img] [img]http://www.simplemachines.org/site_images/lang/dutch.gif[/img]
If you have any translations for any other languages, I would be grateful if you would send them to me via PM or in the Mods topic.

[b][color=blue]Changelog[/color][/b]
[i]2.2.5 - 14th April 2009[/i]
o Code upgraded for RC1
o Integrated 1.1.x and 2.0 packages
o Major changes mean no packaged upgrade option, but your past referrals will remain.

[i][color=red]2.2.6 - 23rd April 2009[/color][/i]
o Fixed 2 bugs in 2.0 and 1 bug in 1.1.x

[i][color=red]2.2.7.1 - 20th December 2009[/color][/i]
o Updated to support RC2
o Added Dutch language

[i][color=red]2.2.7.2 - 7th January 2010[/color][/i]
! Fixed select box
! Fixed referral link to point to register page