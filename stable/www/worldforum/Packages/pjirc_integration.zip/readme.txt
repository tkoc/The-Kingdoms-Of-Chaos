[center][color=green][size=3][b]PJIRC Integration[b][/size][/color]
[b]Created by [url=http://www.codewithus.net/index.php?action=profile;u=1] Anthony[/url][/b]
[/center]

[hr]

[color=blue][size=2][b]Compatibility[/b][/size][/color]
SMF 2.0 RC1-1

[color=blue][size=2][b]Description[/b][/size][/color]
Just a simple mod that integrates PJIRC.

[color=blue][size=2][b]Demo[/b][/size][/color]
[url=http://www.codewithus.net/forums/index.php?action=chat]http://www.codewithus.net/forums/index.php?action=chat[/url]

[color=blue][size=2][b]Changelog[/b][/size][/color]
1.0-Initial release
1.1-Bug Fixes and custom quit message!
1.2-Now uses user default smileys and shows in the linktree.