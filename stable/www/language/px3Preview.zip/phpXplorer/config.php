<?php
/* Copyright notice */

// This file is build up as PHP array.
// Assignments have to be comma separated.


// Do not edit this line
$this->aConfig = array_merge($this->aConfig, array(

#'bDebug' => false,
  // Show debug pane. Show full error messages with filename and line number.


#'bDevelopment' => false,
  // Show cache pane (F8) to rebuild the application level cache.
  // All JavaScript and CSS files are included separately.


'aContact' => array(
	'sOrganisation' => 'phpXplorer',
	'sOrganisationInfo' => '~subTitle',
	'sDepartment' => '',
	'sPerson' => 'Tobias Bender',
	'sStreet' => 'Horngasse 6',
	'sCity' => '52064 Aachen',
	'sCountry' => 'Germany',
	'sTelefon' => '+49 241 450 8005',
	'sTelefax' => '',
	'sEmail' => 'tobias@phpxplorer.org'
),
	// Contact form information.
	// All properties get listed as they appear. Just add or change properties as you need.
	// sEmail is required if you will make use of the contact form.


#'bContact' => true,
	// Show contact form


#'sSystemLanguage' => 'en',
  // Used if there is no translation in the requested language.
  // Each translation file gets commented with this language.
  // Default interface language for new users. The interface
  // language can be set individually for/by each user in its profile.
	// Keywords of this language are used to extend all translation files.


#'bCreateHomes' => false,
  // Create a personal folder (home) for each user below ../phpXplorer/homes.


#'sEncoding' => 'utf-8',
  // Has to be set depending on the charset of your translation and filesystem data (Russian -> windows-1251) 


#'sAuthentication' =>  'phpXplorer://default.pxAuthenticationHtpasswd',
  // Leave empty for no authentication.


#'sNoAuthUser' => 'root',
  // User if there is no authentication.


#'sUMask' => '0000',

#'sMkDirMode' => 0755,


#'sDefaultBookmark' => 'Demo',
  // Bookmark/Share to load on startup

	
#'aImageMagickExtensions' => array('jpg', 'jpeg', 'gif', 'tif', 'tiff', 'png', 'bmp', 'psd', 'svg', 'pdf'),
  // List of file extensions that could be displayed by ImageMagick


#'aGdExtensions' => array('jpg', 'jpeg', 'gif', 'png'),


#'aContentLanguages' => array('en', 'de'),


#'aModuleOrder' => array('System'),
  // Module import order


#'sLogoUrl' => './modules/Customization.pxm/graphics/logo.png',

'sId' => '##ID##',

'sVersion' => 'px3Preview'

// Do not edit this line
));

?>