<?php

if (!isset($_SERVER)) {
	$_SERVER =& $HTTP_SERVER_VARS;
	$_GET =& $HTTP_GET_VARS;	
}

$sCacheId = md5($_SERVER['QUERY_STRING']);

if (isset($_GET['sShare'])) {
	$sShare = $_GET['sShare'];
} else {
	die('Please set sShare parameter');
}

if (isset($_GET['sPath'])) {
	$sPath = $_GET['sPath'];
} else {
	die('Please set sPath parameter');
}

$sExtension = strtolower(strrchr($sPath, '.'));

$aKnownExtensions = array('.jpg', '.jpeg', '.gif', '.png');
if (!in_array($sExtension, $aKnownExtensions)) {
	$sExtension = '.png';
}

$sThumbnailPath = './cache/images/' . $sShare . '/' . $sCacheId . $sExtension;


if (file_exists($sThumbnailPath)) {
	header('Content-Type: image/png');
	readfile($sThumbnailPath);
#	header('Location: ' . $sThumbnailPath);	
} else {
	require dirname(__FILE__) . '/action.php';	
}

?>