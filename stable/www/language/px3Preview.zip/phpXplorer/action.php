<?php
#apd_set_pprof_trace();
#function getMicrotime()
#{
#	list($usec, $sec) = explode(' ', microtime());
#	return ((float)$usec + (float)$sec);
#}

#$iStartTime = getMicrotime();

require_once dirname(__FILE__) . '/modules/System.pxm/pxSystem.php';
$pxp = new pxSystem;
$pxp->aConfig['_bUiMode'] = true;
$pxp->init();

#echo "<br/>" . (getMicrotime() - $iStartTime);

?>