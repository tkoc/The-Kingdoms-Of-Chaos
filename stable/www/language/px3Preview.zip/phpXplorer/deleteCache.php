<?php

	if (strpos(__FILE__, 'htdocs')) {
		die('local');
	}

	if(!function_exists('scandir')) {
		function scandir($dir, $sortorder = 0) {
			if(is_dir($dir) && $dirlist = @opendir($dir)) {
				while(($file = readdir($dirlist)) !== false) {
					$files[] = $file;
				}
				closedir($dirlist);
				return $files;
			} else {
				return false;
			}
		}
	}
	
	function rmdirr($sDir) {
		$aFiles = scandir($sDir);
		if ($aFiles === false) {
			die('Could not read directory');
		}
		foreach ($aFiles as $sFile) {
			if ($sFile != '.' && $sFile != '..') {
				$sPath = $sDir . '/' . $sFile;
				if (is_dir($sPath)) {
					rmdirr($sPath);
					rmdir($sPath);
				} else {
					unlink($sPath);
				}
			}
		}
	}
	
	$sDir = dirname(__FILE__) . '/cache';

	if (!empty($sDir) && is_dir($sDir) && strpos($sDir, 'cache') !== false) {
		rmdirr($sDir);
	} else {
		die('Dir not found');
	}

?>