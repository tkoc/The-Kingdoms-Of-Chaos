<?php

$this->aLanguages['de'] = array_merge($this->aLanguages['de'], array(
  'webserverPermissions' => 'Webserver-Berechtigungen',
  'webserverPermissionsText' => 'Folgende Verzeichnisse ben�tigen Schreibrechte. Bitte stellen Sie sicher das der Webserver/PHP Systembenutzer in diese Verzeichnisse schreiben kann.<br/><a href="http://www.google.de/search?hl=de&q=ftp+file+permissions&btnG=Suche&meta=">Anleitungen suchen</a>',
  'chooseLanguage' => 'Sprache',
  'chooseLanguageText' => 'Diese Sprache wird nach der Installation standardm��ig neuen Benutzern sowie dem administrativen Benutzer (root) zugewiesen. Zudem werden fehlende �bersetzungen in dieser Sprache erg�nzt.',
  'installation' => 'Installation',
  'installationText' => 'Der folgende Dialog f�hrt sie durch die Grundeinstellungen ihrer phpXplorer Installation und wei�t sie auf n�tige Vorbereitungen hin. Die Einstellungen k�nnen nach der Installation in der Datei ~&hellip;/phpXplorer/config.php~ ge�ndert werden.',
  'recheck' => 'erneut pr�fen',
  'adminPassword' => 'Passwort',
  'adminPasswordText' => 'Legen sie das Passwort f�r den Benutzer ~root~ fest. Nach der Installation k�nnen sie sich mit dem Benutzernamen ~root~ und dem Passwort als Administrator anmelden. '
));

?>