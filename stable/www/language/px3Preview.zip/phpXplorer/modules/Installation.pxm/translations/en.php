<?php

$this->aLanguages['en'] = array_merge($this->aLanguages['en'], array(
  'webserverPermissions' => 'Webserver permissions',
  'webserverPermissionsText' => 'The following phpXplorer directories have to be writable. Please enshure that the webserver/PHP system user is allowed to write to these directories.<br/><a href="http://www.google.de/search?hl=de&q=ftp+file+permissions&btnG=Suche&meta=">Search for instructions</a>',
  'chooseLanguage' => 'Language',
  'chooseLanguageText' => 'Diese Sprache wird nach der Installation standardm��ig neuen Benutzern sowie dem administrativen Benutzer (root) zugewiesen. Zudem werden fehlende �bersetzungen in dieser Sprache erg�nzt.',
  'installation' => 'Installation',
  'installationText' => 'The following dialog leads you through the basic configuration of your phpXplorer installation and points you out to the needed preparations. These settings could be modified in ~&hellip;/phpXplorer/config.php~ after installation.',
  'recheck' => 'recheck',
  'adminPassword' => 'Password',
  'adminPasswordText' => 'Legen sie das Passwort f�r den Benutzer ~root~ fest. Nach der Installation k�nnen sie sich mit dem Benutzernamen ~root~ und dem Passwort als Administrator anmelden. '
));

?>