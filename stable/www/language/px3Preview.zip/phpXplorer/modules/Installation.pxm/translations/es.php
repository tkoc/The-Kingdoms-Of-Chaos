<?php

$this->aLanguages['es'] = array_merge($this->aLanguages['es'], array(
  'adminPasswordText' => '', // Legen sie das Passwort f�r den Benutzer ~root~ fest. Nach der Installation k�nnen sie sich mit dem Benutzernamen ~root~ und dem Passwort als Administrator anmelden. 
  'adminPassword' => '', // Password
  'recheck' => '', // recheck
  'installationText' => '', // The following dialog leads you through the basic configuration of your phpXplorer installation and points you out to the needed preparations. These settings could be modified in ~&hellip;/phpXplorer/config.php~ after installation.
  'installation' => '', // Installation
  'chooseLanguageText' => '', // Diese Sprache wird nach der Installation standardm��ig neuen Benutzern sowie dem administrativen Benutzer (root) zugewiesen. Zudem werden fehlende �bersetzungen in dieser Sprache erg�nzt.
  'chooseLanguage' => '', // Language
  'webserverPermissionsText' => '', // The following phpXplorer directories have to be writable. Please enshure that the webserver/PHP system user is allowed to write to these directories.<br/><a href="http://www.google.de/search?hl=de&q=ftp+file+permissions&btnG=Suche&meta=">Search for instructions</a>
  'webserverPermissions' => '', // Webserver permission
));

?>