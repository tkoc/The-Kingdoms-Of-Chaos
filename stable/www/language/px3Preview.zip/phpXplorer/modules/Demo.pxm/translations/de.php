<?php

$this->aLanguages['de'] = array_merge($this->aLanguages['de'], array(
  '' => ''
));

?>