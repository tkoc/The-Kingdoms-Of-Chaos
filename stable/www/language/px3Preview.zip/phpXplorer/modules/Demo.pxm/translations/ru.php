<?php

$this->aLanguages['ru'] = array_merge($this->aLanguages['ru'], array(
  '' => ''
));

?>