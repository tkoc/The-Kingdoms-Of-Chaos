<?php

$this->aLanguages['sv'] = array_merge($this->aLanguages['sv'], array(
  '' => ''
));

?>