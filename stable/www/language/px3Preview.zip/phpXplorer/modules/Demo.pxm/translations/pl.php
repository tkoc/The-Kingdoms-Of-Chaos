<?php

$this->aLanguages['pl'] = array_merge($this->aLanguages['pl'], array(
  '' => ''
));

?>