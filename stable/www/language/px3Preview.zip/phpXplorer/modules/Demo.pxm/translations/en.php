<?php

$this->aLanguages['en'] = array_merge($this->aLanguages['en'], array(
  '' => ''
));

?>