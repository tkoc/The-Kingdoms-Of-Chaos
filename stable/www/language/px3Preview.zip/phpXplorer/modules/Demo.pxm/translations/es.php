<?php

$this->aLanguages['es'] = array_merge($this->aLanguages['es'], array(
  '' => ''
));

?>