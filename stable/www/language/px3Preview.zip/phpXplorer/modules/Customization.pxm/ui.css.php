<?php
	header('Content-Type: text/css');
?>
/*<style*/

div.pxHomepage #logo {
	margin: 1em 0 2em 0;
}