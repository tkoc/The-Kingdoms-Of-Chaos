<?php

$this->aLanguages['nl'] = array_merge($this->aLanguages['nl'], array(
  'home.introduction' => '',
  '' => ''
));

?>