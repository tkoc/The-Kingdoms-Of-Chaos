<?php

$this->aLanguages['fr'] = array_merge($this->aLanguages['fr'], array(
  'home.introduction' => '',
  '' => ''
));

?>