<?php

$this->aLanguages['de'] = array_merge($this->aLanguages['de'], array(
  '' => '',
  'home.introduction' => 'phpXplorer ist ein Open Source Dokument Management System. Das System wird auf einem Internetserver installiert und kann von jedem Rechner mit Internetanschluss aus bedient werden.'
));

?>