<?php
/* Copyright notice */

/**
 * Function/Method data type
 * @access private
 */
class pxClassParserFunction
{
	/**
	 * Visibility level of class method.
	 * 
	 * Valid values are T_VAR, T_PUBLIC, T_PROTECTED and T_PRIVATE
	 * 
	 * @var integer
	 */
	var $iVisibility;

	/**
	 * Class method name
	 * 
	 * @var string
	 */
	var $sName;
	
	/**
	 * Assoc array with tag names as keys and arrays with all occured key values as value
	 * 
	 * @var array
	 */
	var $aCommentTags = array();
	
	function pxClassParserFunction($iVisibility, $sName, $sComment)
	{
		$this->aCommentTags = pxClassParser::_splitComment($sComment);
		$this->iVisibility = $iVisibility;
		$this->sName = $sName;
	}
}

?>