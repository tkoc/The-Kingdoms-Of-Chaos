<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxOffice.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @extensions
 *   odt => application/vnd.oasis.opendocument.text
 *   ods => application/vnd.oasis.opendocument.spreadsheet
 *   odp => application/vnd.oasis.opendocument.presentation
 *   odg => application/vnd.oasis.opendocument.graphics
 *   odb => application/vnd.oasis.opendocument.database
 */
class pxOpenDocument extends pxOffice
{
}

?>