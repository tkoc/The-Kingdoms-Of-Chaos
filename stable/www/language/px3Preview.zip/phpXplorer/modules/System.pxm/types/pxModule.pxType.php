<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaDirectories.pxType.php';

/**
 * Module
 *
 * @extensions pxm
 * @contains pxObject
 * @belongsTo /modules
 * @expandSubtypes pxModule
 * @edit
 */
class pxModule extends pxMetaDirectories
{
	/**
	 * @var string
	 * @edit Input
	 */
	var $sOwner;
	
	/**
	 * @var string
	 * @edit Input
	 */
	var $sOwnerMail;
	
	/**
	 * @var string
	 * @edit Input
	 */
	var $sVersion;
	
	/**
	 * @var string
	 * @edit Textarea
	 */
	var $sDescription;

	/**
	 * @var array
	 * @edit Array
	 */
	var $aTutorials;

	/**
	 * @var array
	 * @edit Array
	 */
	var $aCssIncludes;

	/**
	 * @var array
	 * @edit Array(rows=20)
	 */
	var $aJsIncludes;
	
	/**
	 * @var boolean
	 * @edit Checkbox
	 */
	var $bIndipendent = false;
}

?>