<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaFiles.pxType.php';

/**
 * @edit
 */
class pxFile extends pxMetaFiles
{
}

?>