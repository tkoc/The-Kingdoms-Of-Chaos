<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxTextFiles.pxType.php';

/**
 * Abstract class for all Apache .ht* configuration files 
 *
 * @extensions
 *   htaccess => text/plain
 *   htgroups => text/plain
 *   htpasswd => text/plain
 */
class pxApache extends pxTextFiles
{
}

?>