<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxObject.pxType.php';

/**
 * @abstract
 * @defaultActions pxMetaFiles_openView
 */
class pxFiles extends pxObject
{
	function getContents()
	{
		global $pxp;

		return $pxp->aShares[$this->sShare]->oVfs->file_get_contents(
			pxUtil::buildPath($pxp->aShares[$this->sShare]->sBaseDir, $this->sRelDir) .
			'/' . $this->sName
		);
	}
	
	function setContents($sContent)
	{
		global $pxp;

		return $pxp->oShare->oVfs->file_put_contents(
			$pxp->sFullPathIn,
			$sContent
		);
	}
}

?>