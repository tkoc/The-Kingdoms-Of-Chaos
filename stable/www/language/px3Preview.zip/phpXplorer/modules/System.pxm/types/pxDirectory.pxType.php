<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaDirectories.pxType.php';

/**
 * Concrete directroy class
 *
 * @contains pxObject
 * @edit
 */
class pxDirectory extends pxMetaDirectories
{
}

?>