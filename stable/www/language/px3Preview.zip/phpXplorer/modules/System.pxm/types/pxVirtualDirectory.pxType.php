<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaDirectories.pxType.php';

/**
 * @contains pxData
 * @extensions pxv
 * @expandSubtypes pxVirtualDirectory
 * @edit
 */
class pxVirtualDirectory extends pxMetaDirectories
{
	/**
	 * @var string
	 * @edit Input
	 */
	var $sQuery;
	
	/**
	 * @var boolean
	 * @edit Checkbox
	 */
	var $bSearchMatchCase = false;
}

?>