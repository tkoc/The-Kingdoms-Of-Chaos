<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaFiles.pxType.php';

/**
 * phpXplorer user profile
 *
 * A profile stores address information, application state and phpXplorer bookmarks 
 *
 * @extensions pxProfile
 * @belongsTo /profiles
 * @expandSubtypes pxProfile
 * @edit
 */
class pxProfile extends pxMetaFiles
{
	/**
	 * @var string
	 * @edit Input
	 */
	var $sFullName;

	/**
	 * @var string
	 * @edit Input
	 * @validate email(required=true)
	 */
	var $sEmail;

	/**
	 * @var string
	 * @edit Select
	 */
	var $sFrontendLanguage = 'en';

	/**
	 * @var array
	 * @edit Array
	 * @permission pxAdministrator
	 */
	var $aBookmarks = array();

	/**
	 * @var integer
	 * @view Datetime
	 */
	var $iLastLogin;

	/**
	 * @var integer
	 * @view Datetime
	 */
	var $iLastLogout;

	/**
	 * Returns options of selection member types
	 * 
	 * @param string $sMember Selection member ID
	 * 
	 * @return array Associative array with options
	 */
	function _getOptions($sMember, $bManualOptions = false)
	{
		global $pxp;

		switch($sMember)
		{
			case 'sFrontendLanguage':
				$aLanguages = array();
				$pxp->loadLanguageCodes();
				$oQuery = new pxQuery;
				$oQuery->sDirectory = $pxp->sModuleDir . '/System.pxm/translations';
				$oQuery->bPermissionCheck = false;				
				$aFiles = $pxp->oVfs->ls($oQuery);
				foreach ($aFiles as $oFile) {
					$sLanguage = substr($oFile->sName, 0, strpos($oFile->sName, '.'));
					if (strlen($sLanguage) == 2 or strlen($sLanguage) == 3) {
						$aLanguages[$sLanguage] = $pxp->aLanguageCodes[$sLanguage];
					}
				}
				return $aLanguages;
				break;
			default:
				return parent::_getOptions($sMember, $bManualOptions);
				break;
		}
	}

	/**
	 * Constructor
	 */
	function pxProfile()
	{
		global $pxp;
		
		parent::pxFiles();

		$this->sLanguage = $pxp->aConfig['sSystemLanguage'];
	}
}

?>