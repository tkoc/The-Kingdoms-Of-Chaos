<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaFiles.pxType.php';

/**
 * A bundle of permissions, events and parameters to build roles or define local settings for users 
 *
 * @extensions pxSetting
 * @belongsTo pxShare pxData phpXplorer:
 * @defaultActions pxSetting_edit
 * @edit
 */
class pxSetting extends pxMetaFiles
{
	/**
	 * Permissions can be either given for a whole type,
	 * a base action or a special action.
	 * 
	 * ('typeID', 'typeID.baseAction', 'typeID.mySpecialAction')
	 *
	 * @var array
	 */
	var $aPermissions = array();

	/**
	 * Events can be intercepted if something happens on type,
	 * base action or action level. An event should trigger
	 * predefined actions to avoid the evaluation of PHP code. 
	 * 
	 * ('type' => 'do()', 'type.baseAction' => 'do()', 'type.mySpecialAction' => 'do()')
	 * 
	 * @var array
	 */
	var $aEvents = array();
	
	/**
	 * 
	 */
	var $aCompiledEvents = array();

	/**
	 * Action parameters
	 * 
	 * ('type.action.parameter' => 123) 
	 * 
	 * @var array
	 */
	var $aParameters = array();

	/* internal */

	/**
	 * User roles array gets fill during setting collection 
	 *
	 * @var array
	 */
	var $aRoles = array('pxEveryone');

	/**
	 * Associative array which stores allowed actions for a type
	 * 
	 * @var array 
	 */
	var $aAllowedActions = array();

	/**
	 * Prevent serialisation of private, runtime and empty members
	 */
	function __sleep() {
		$aVars = array_flip(parent::__sleep());

		unset($aVars['aRoles']);
		unset($aVars['aAllowedActions']);

		return array_keys($aVars);
	}
}

?>