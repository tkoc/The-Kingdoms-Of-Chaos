<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxTextFiles.pxType.php';

/**
 * @extensions
 *   js => text/javascript
 *   asp => text/plain
 *   py => text/plain
 *   rb => text/plain
 *   pl => application/x-perl
 *   sql => text/plain
 *   java => text/plain
 *   as => text/plain
 * @edit
 */
class pxScript extends pxTextFiles
{
}

?>