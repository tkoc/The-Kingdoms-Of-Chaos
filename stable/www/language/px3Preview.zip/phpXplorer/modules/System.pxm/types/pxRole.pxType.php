<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxSetting.pxType.php';

/**
 * @extensions pxRole
 * @belongsTo pxm/roles
 * @edit
 */
class pxRole extends pxSetting
{
	/**
	 * @var string
	 * @edit SelectTranslated(namespace=role)
	 */
	var $sParentRole;

	var $aSubRoles = array();

	/**
	 * Returns options of selection member types
	 * 
	 * @param string $sMember Selection member ID
	 * @return array Associative array with options
	 */
	function _getOptions($sMember, $bManualOptions = false)
	{
		global $pxp;

		switch($sMember){
			case 'sParentRole':
				$pxp->loadTranslation();
				$aRoles = array('' => $pxp->aTranslation['option.none']);
				foreach ($pxp->aRoles as $sKey => $oRole) {
					if ($sKey != 'pxEveryone' && $sKey != 'pxAuthenticated') {
						$aRoles[$sKey] = $sKey;
					}
				}
				return $aRoles;
				break;
			default:
				return parent::_getOptions($sMember, $bManualOptions);
				break;
		}
	}
}

?>