<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxBinaryFiles.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @abstract
 */
class pxOffice extends pxBinaryFiles
{
}

?>