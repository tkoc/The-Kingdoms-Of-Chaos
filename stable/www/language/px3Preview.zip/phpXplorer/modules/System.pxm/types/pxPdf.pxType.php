<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxOffice.pxType.php';

/**
 * JavaScript file
 *
 * @extensions
 *   pdf => application/pdf
 */
class pxPdf extends pxOffice
{
}

?>