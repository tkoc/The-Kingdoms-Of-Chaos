<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxTextFiles.pxType.php';

/**
 * @extensions
 *   xml => text/xml
 *   xhtml => application/xhtml+xml
 * @edit
 */
class pxXml extends pxTextFiles
{
}

?>