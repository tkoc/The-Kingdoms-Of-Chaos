<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxOffice.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @extensions
 *   doc => application/msword
 *   xls => application/msexcel
 *   ppt => application/mspowerpoint
 *   rtf => application/rtf
 */
class pxMsOffice extends pxOffice
{
}

?>