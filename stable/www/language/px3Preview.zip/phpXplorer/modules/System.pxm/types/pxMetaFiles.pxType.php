<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxFiles.pxType.php';

/**
 * @defaultActions pxObject_editProperties
 * @mixin pxMeta
 * @abstract 
 */
class pxMetaFiles extends pxFiles
{
}

?>