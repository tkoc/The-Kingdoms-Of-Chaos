<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxXml.pxType.php';

/**
 * @extensions
 *   svg => image/svg+xml
 */
class pxSvg extends pxXml
{
}

?>