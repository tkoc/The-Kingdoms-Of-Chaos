<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxBinaryFiles.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @extensions
 *   zip => application/zip
 *   rar => application/x-rar-compressed
 *   jar => application/x-zip-compression
 */
class pxArchive extends pxBinaryFiles
{
}

?>