<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxFiles.pxType.php';

/**
 * pxAuthentication user object 
 *
 * @belongsTo Authentication:
 * @extensions pxAuthUser
 * @defaultActions pxObject_editProperties
 * @expandSubtypes pxVfsAuthenticationUser
 * @edit
 */
class pxVfsAuthenticationUser extends pxFiles
{
	/**
	 * Password
	 *
	 * @var string
	 * @edit Password
	 * @validate string(min_length=1)
	 */
	var $sPassword = '';
	
	/**
	 * Password confirmation
	 *
	 * @var string
	 * @edit Password
	 * @validate equalTo(compareTo=sPassword)
	 */
	var $sPasswordConfirm = '';
}

?>