<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxDirectories.pxType.php';

/**
 * @defaultActions pxMetaDirectories_openDetails
 * @contains pxObject
 * @mixin pxMeta
 * @abstract 
 */
class pxMetaDirectories extends pxDirectories
{
}

?>