<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxBinaryFiles.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @extensions
 *   mpg => video/mpeg
 *   mpeg => video/mpeg
 *   avi => video/x-msvideo
 *   wmv => video/x-ms-wmv
 *   mov => video/quicktime
 *   swf => application/x-shockwave-flash
 *   fla => application/octet-stream
 */
class pxVideo extends pxBinaryFiles
{
}

?>