<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaFiles.pxType.php';

/**
 * Base class for all text files 
 *
 * @abstract
 * @defaultActions pxMetaFiles_openView pxTextFiles_edit
 */
class pxTextFiles extends pxMetaFiles
{
}

?>