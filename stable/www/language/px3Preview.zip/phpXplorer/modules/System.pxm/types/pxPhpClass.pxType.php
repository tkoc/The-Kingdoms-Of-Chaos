<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxPhp.pxType.php';

/**
 * PHP class object implements functionality to access class members
 *
 * @abstract
 */
class pxPhpClass extends pxPhp
{
	/**
	 * List of pxProperty member objects
	 *
	 * @access protected
	 * @var array
	 */
	var $aProperties;

	/**
	 * Fills and returns aProperties with all ascertainable properties of this class
	 *
	 * @return array
	 */
	function &getProperties()
	{
		global $pxp;

		$pxp->loadType('pxProperty');

		if (isset($this->aProperties)) {
			return $this->aProperties;
		}
		
#		// serve cache
#		$sCacheFile = $pxp->sCacheDir . '/properties/' . $this->sId . '.serializedPhp';
#		if ($pxp->oVfs->file_exists($sCacheFile)) {
#			$this->aProperties = unserialize($pxp->oVfs->file_get_contents($sCacheFile));
#			return $this->aProperties;
#		}

		$this->aProperties = array();

   	require_once $pxp->sModuleDir . '/System.pxm/pxClassParser.php';

   	$oParser =& new pxClassParser;

   	switch (strtolower(get_class($this))) {
   		case 'pxaction':
	   		$oParser->parse($pxp->sModuleDir . '/' . $this->sModule . '.pxm/actions/' . $this->sId . '.pxAction.php');
   			break;
   		case 'pxtype':
	   		#$oParser->parse($pxp->sModuleDir . '/' . $this->sModule . '.pxm/types/' . $this->sId . '.pxType.php');
	   		$oParser->parse($pxp->sCacheDir . '/types/' . $this->sId . '.pxType.php');
   			break;
   	}

   	foreach($oParser->aClasses[$this->sId]->aVariables as $oVariable)
   	{
   		$sId = substr($oVariable->sName, 1);

   		if ($oVariable->tagExists('view')) {
   			$sTagValue = $oVariable->getTagValue('view');
   			$sMode = 'view';
   		} else {
   			if ($oVariable->tagExists('edit')) {
   				$sTagValue = $oVariable->getTagValue('edit');
   				$sMode = 'edit';
   			} else {
   				continue;
   			}
   		}

   		$this->aProperties[$sId] =& new pxProperty($sId);

   		$this->aProperties[$sId]->sMode = $sMode;
   		$this->aProperties[$sId]->sValue = $oVariable->sValue;
   		if ($oVariable->tagExists('var')) {
   			$this->aProperties[$sId]->sDataType = $oVariable->getTagValue('var');  
   		} else {
   			switch (substr($sId, 0, 1)) {
   				case 's': $sType = 'string'; break;
   				case 'i': $sType = 'integer'; break;
   				case 'a': $sType = 'array'; break;
   			}
   			if (!empty($sType)) {
   				$this->aProperties[$sId]->sDataType = $sType;
   			}
   		}
   		$aParts = pxClassParser::parseTagValue($sTagValue);
   		$this->aProperties[$sId]->sWidget = $aParts['sName'];
   		$this->aProperties[$sId]->aParameters = $aParts['aParameters'];

   		if ($oVariable->tagExists('validate')) {
   			$sValidationTagValue = $oVariable->getTagValue('validate');
   			$aParts = pxClassParser::parseTagValue($sValidationTagValue);
   			$this->aProperties[$sId]->sValidation = $aParts['sName'];
   			$this->aProperties[$sId]->aValidationParameters = $aParts['aParameters'];
   		}

   		if ($oVariable->tagExists('format')) {
   			$sFormatTagValue = $oVariable->getTagValue('format');
   			$aParts = pxClassParser::parseTagValue($sFormatTagValue);
   			$this->aProperties[$sId]->sFormat = $aParts['sName'];
   			$this->aProperties[$sId]->aFormatParameters = $aParts['aParameters'];
   		}

   		$this->aProperties[$sId]->sStore = $oVariable->getTagValue('store');
			$this->aProperties[$sId]->sPermission = $oVariable->getTagValue('permission');   		
   	}

		// build cache
#		$pxp->oVfs->file_put_contents($sCacheFile, serialize($this->aProperties));

		return $this->aProperties;
	}

	/**
	 * Fills and returns aProperties with all ascertainable properties of this class
	 *
	 * @return array
	 */
	function &getVariables($bObjects = false)
	{
		global $pxp;

   	require_once $pxp->sModuleDir . '/System.pxm/pxClassParser.php';

   	$oParser =& new pxClassParser;

   	switch (strtolower(get_class($this))) {
   	case 'pxaction':
   		$oParser->parse($pxp->sModuleDir . '/' . $this->sModule . '.pxm/actions/' . $this->sId . '.pxAction.php');
   		break;
   	case 'pxtype':
   		#$oParser->parse($pxp->sModuleDir . '/' . $this->sModule . '.pxm/types/' . $this->sId . '.pxType.php');
			$oParser->parse($pxp->sCacheDir . '/types/' . $this->sId . '.pxType.php');
   		break;
   	}
   	
   	$aVariables = array();

   	foreach($oParser->aClasses[$this->sId]->aVariables as $oVariable) {
			$sId = substr($oVariable->sName, 1);
			$sDataType = substr($sId, 0, 1);
			if ($bObjects == false) {
				if ($sDataType == 'o') {
					continue;
				}
			}
   		$aVariables[] = $sId;
   	}

   	return $aVariables;
	}
}

?>