<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaFiles.pxType.php';

/**
 * Type/class property/member
 */
class pxProperty extends pxMetaFiles
{
	/**
	 * Class name of type or action class that contains this property
	 */
	#var $sContainerClass;

	/**
	 * View or edit mode
	 *
	 * @var string
	 * @view Input
	 */
	var $sMode = 'edit';
	
	/**
	 * PHP data type
	 * 
	 * @var string
	 * @view Select
	 */
	var $sDataType = 'string';

	/**
	 * Widget set by mode tag
	 * 
	 * @var string
	 * @view Select
	 */
	var $sWidget = 'string';

	/**
	 * Declared class member value
	 * 
	 * @var mixed
	 * @view Input
	 */
	var $sValue;

	/**
	 * Widget instance
	 * 
	 * @var object
	 */
	var $oWidget;

	/**
	 * List of name value pairs to control the appearance and behaviour
	 * 
	 * @var array
	 * @view Array
	 * 
	 */
	var $aParameters = array();

	/**
	 * @var string
	 * @view Input
	 */
	var $sValidation;

	/**
	 * @var array
	 * @view Input
	 */
	var $aValidationParameters;

	/**
	 * @var string
	 * @view Input
	 */
	var $sFormat;

	/**
	 * @var array
	 * @view array
	 */
	var $aFormatParameters;

	/**
	 * @var string
	 * @view Input
	 */
	var $sPermission;

	/**
	 * system || os
	 *
	 * @var string
	 * @view Input
	 */
	var $sStore;

	/**
	 * Constructor
	 */
	function pxProperty($sId) {
		parent::pxMetaFiles();
		$this->sId = $sId;
	}
}

?>