<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxObject.pxType.php';

/**
 * Abstract class to bundle all directory types
 *
 * @contains pxObject
 * @abstract
 * @defaultActions pxDirectories_openPreview
 */
class pxDirectories extends pxObject
{
	/**
	 * @var array
	 * @edit Array
	 */
	var $aDefaultTags = Array();
}

?>