<?php
/* Copyright notice */

/**
 * @abstract
 */
class pxGlobal
{
}

?>