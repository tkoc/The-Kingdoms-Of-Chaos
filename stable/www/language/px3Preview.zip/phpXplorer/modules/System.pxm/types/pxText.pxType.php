<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxTextFiles.pxType.php';

/**
 * Text file
 *
 * @extensions
 *   txt => text/plain
 *   ini => text/plain
 *   css => test/css
 *   serializedPhp => text/plain
 * @edit
 */
class pxText extends pxTextFiles
{
}

?>