<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaFiles.pxType.php';

/**
 * User role assignment 
 * 
 * @extensions pxUser
 * @belongsTo phpXplorer: pxShares pxShare pxData
 * @expandSubtypes pxObject pxUser
 * @edit
 */
class pxUser extends pxMetaFiles
{
	/**
	 * List of users roles
	 *
	 * @var array
	 * @edit MultipleTranslated(namespace=role)
	 */
	var $aRoles = array();

	/**
	 * Returns options of selection member types
	 * 
	 * @param string $sMember Selection member ID
	 * @return array Associative array with options
	 */
	function _getOptions($sMember, $bManualOptions = false)
	{
		global $pxp;

		switch($sMember)
		{
			case 'aRoles':

				$oSettings = $pxp->aShares[$this->sShare]->getSettings($this->sRelDir, $this->sOwner);
				$aAllowedRoles = array();

				foreach($oSettings->aRoles as $sRole) {
					$aAllowedRoles[] = $sRole;
					$aAllowedRoles = array_merge($aAllowedRoles, $pxp->aRoles[$sRole]->aSubRoles);
				}

				$aRoles = array();
				foreach ($pxp->aRoles as $sKey => $oRole) {
					if (in_array($sKey, $aAllowedRoles) && $sKey != 'pxEveryone' && $sKey != 'pxAuthenticated') {
						$aRoles[$sKey] = $sKey;
					}
				}
				return $aRoles;
				break;
			default:
				return parent::_getOptions($sMember, $bManualOptions);
				break;
		}
	}

	/**
	 * 
	 */
	 /*
	function store($sPathIn = null){
		$this->sRelDir .=
			pxUtil::buildPath(
				$this->sRelDir,
				'/.phpXplorer'
			);

		parent::store($sPathIn);

		#if (!strrpos($this->sRelDir, '.phpXplorer') ==  strlen($this->sRelDir) - 11) {
		#}
	}
	*/
}

?>