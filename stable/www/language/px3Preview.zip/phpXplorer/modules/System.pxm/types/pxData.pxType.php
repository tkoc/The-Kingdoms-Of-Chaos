<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaDirectories.pxType.php';

/**
 * Directory with phpXplorer�s configuration files or instance data
 *
 * Configuration directories are called .phpXplorer by default.
 * Object instance data is store in a subfolder called .phpXplorer/.objects 
 * if there is no database installed
 *
 * @extensions phpXplorer objects
 * @contains pxUser pxSetting pxData pxApache pxText
 * @edit
 */
class pxData extends pxMetaDirectories
{
}

?>