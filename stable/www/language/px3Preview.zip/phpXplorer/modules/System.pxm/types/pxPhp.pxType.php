<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxScript.pxType.php';

/**
 * PHP file
 *
 * @extensions
 *  php => application/x-httpd-php
 *  php4 => application/x-httpd-php
 *  php5 => application/x-httpd-php
 *  phtml => application/x-httpd-php
 * @edit
 */
class pxPhp extends pxScript
{
	function execute()
	{
		global $pxp;

		require_once
			pxUtil::buildPath($pxp->aShares[$this->sShare]->sBaseDir, $this->sRelDir) .
			'/' . $this->sName;
	}
}

?>