<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxBinaryFiles.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @extensions
 *   exe => application/octet-stream
 *   bin => application/octet-stream
 */
class pxBinary extends pxBinaryFiles
{
}

?>