<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxMetaFiles.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @abstract
 * @defaultActions pxMetaFiles_openDownload
 */
class pxBinaryFiles extends pxMetaFiles
{
}

?>