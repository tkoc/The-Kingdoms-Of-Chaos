<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxBinaryFiles.pxType.php';

/**
 * Abstract class for binary files 
 *
 * @extensions
 *   mp3 => audio/mpeg
 *   wav => audio/x-wav
 *   ogg => application/ogg
 * @defaultActions pxMetaFiles_openView
 */
class pxAudio extends pxBinaryFiles
{
}

?>