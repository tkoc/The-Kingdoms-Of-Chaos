<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxTextFiles.pxType.php';

/**
 * Hypertext Markup Language file
 *
 * @extensions
 *   htm => text/html
 *   html => text/html
 *   shtml => text/html
 * @edit
 */
class pxHtml extends pxTextFiles
{
	function loadFileMetaData()
	{
		global $pxp;

		$sContent =
			$pxp->aShares[$this->sShare]->oVfs->file_get_contents(
				$this->getFullPath()
			);
		
		// Parse html title
		$iTitleStart = strpos($sContent, '<title>');		
		if ($iTitleStart !== false) {
			$iTitleStart += 7;
			$iTitleEnd = strpos($sContent, '</title>', $iTitleStart);
			if ($iTitleEnd !== false) {
				$this->sTitle = substr($sContent, $iTitleStart, $iTitleEnd - $iTitleStart);
			}
		}
	}
}

?>