<?php
/* Copyright notice */

/**
 * Variable data type
 * @access private
 */
class pxClassParserVariable
{
	/**
	 * Visibility level of class member.
	 * 
	 * Valid values are T_VAR, T_PUBLIC, T_PROTECTED and T_PRIVATE
	 * 
	 * @var integer
	 */
	var $iVisibility;

	/**
	 * Class member name
	 * 
	 * @var string
	 */
	var $sName;

	/**
	 * Initial value of the class member
	 * 
	 * @var mixed 
	 */
	var $mValue;

	/**
	 * Assoc array with tag names as keys and arrays with all occured key values as value
	 * 
	 * @var array
	 */
	var $aCommentTags = array();

	function pxClassParserVariable($iVisibility, $sName, $sValue, $sComment)
	{
		$this->aCommentTags = pxClassParser::_splitComment($sComment);

		/**
		 * Visibility marks are used in the following order.
		 * 
		 * 1. PHP5 visibility keywords like public, protected and private
		 * 2. @pxAccess tag
		 * 3. @access tag (phpDocumentor like)
		 * 4. A leading '_' char is a mark for private class members
		 * 
		 * Class members without any visibility mark a treated as public
		 */
		if ($iVisibility == T_VAR) {

			// Is there a @access tag?

			if (isset($this->aCommentTags['access'])) {

				// Translate string to token constant

				switch ($this->aCommentTags['access'][0]) {

					case 'public':
						$this->iVisibility = T_PUBLIC;
					break;

					case 'protected':
						$this->iVisibility = T_PROTECTED;
					break;

					case 'private':
						$this->iVisibility = T_PRIVATE;
					break;
				}

			} else {
				
				// No access tag found.
				// Is there a leading '_' char?
				
				if (strpos($sName, '$_') === 0) {
					$iVisibility = T_PRIVATE;
				} else {
					// Class members without any visibility mark are treated as public.
					$iVisibility = T_PUBLIC;
				}
			}
		} else {
			// Parameter has already got a value of T_PUBLIC, T_PROTECTED or T_PRIVATE
			$this->iVisibility = $iVisibility;
		}

		$this->sName = $sName;
		$this->sValue = $sValue;
	}
	
	/**
	 * Returns command tag value
	 * 
	 * @param string $sTag Tag ID
	 * 
	 * @return mixed Tag value
	 */
	function getTagValue($sTag)
	{
		if (isset($this->aCommentTags[$sTag])) {		
			return $this->aCommentTags[$sTag];
		} else {
			return null;
		}
	}
	
	/**
	 * Returns true or false depending on the existance of $sTag
	 * 
	 * @param string $sTag Tag ID
	 * 
	 * @return boolean
	 */
	function tagExists($sTag)
	{
		return isset($this->aCommentTags[$sTag]);
	}
}

?>