<?php

    /*----------------------------------------------------------------------
        PHP JSON Class
        ==============
        The PHP JSON Class can be used to encode a php array or object into
        Java Script Object Notation, without the need for an additional PHP
        Extension.
        
        Normal usage is as follows:
        
            $json = new json;
            $encoded = $json->encode($var);
            echo $encoded;

        Version 0.5
        Copyright Jack Sleight - www.reallyshiny.com
        This script is licensed under the:
            Creative Commons Attribution-ShareAlike 2.5 License
    ----------------------------------------------------------------------*/

class pxJson
{
	function encode($mData) {
		return $this->_encode(NULL, $mData);
	}

	function _encode($key, $value, $parent = NULL)
	{
		$sType = $this->type($key, $value);

		switch ($sType) {
			case 'string':
				$value = '"' . $this->escape($value) . '"';
			break;
			case 'number':
				$value = $value;
			break;
			case 'boolean':
				$value = ($value) ? 'true' : 'false';
			break;
			case 'array':
				$value = '[' . $this->loop($value, $sType) . ']';
			break;
			case 'object':
				$value = '{' . $this->loop($value, $sType) . '}';
			break;
			case 'null':
				$value = 'null';
			break;
		}

		if(!is_null($key) && $parent != 'array') {
			$value = '"' . $key . '":' . $value;
		}

		return $value;
	}

	function type($key, $value)
	{
		if (is_object($value)) {
			$sType = 'object';
		}
		else if(is_string($value)) {
			$sType = 'string';
		}
		else if(is_int($value) || is_float($value)) {
			$sType = 'number';
		}
		else if(is_bool($value)) {
			$sType = 'boolean';
		}
		else if(is_array($value)) {
			$sType = $this->isAssoc($value) ? 'object' : 'array';
		}
		else if(is_null($value)) {
			$sType = 'null';
		}

		return $sType;
	}

	function loop($input, $sType)
	{
		$output = NULL;

		foreach($input as $key => $value) {
			$output .= $this->_encode($key, $value, $sType) . ',';
		}

		$output = trim($output, ',');

		return $output;
	}    

	function escape($sString) {
		return str_replace(
			array('\\',   '"',  '/',  "\b", "\f", "\n", "\r", "\t", "\u"),
			array('\\\\', '\"', '\/', '\b', '\f', '\n', '\r', '\t', '\u'),
			$sString
		);
	}

	function isAssoc($array) {
		krsort($array, SORT_STRING);
		return !is_numeric(key($array));
	}
}
?>