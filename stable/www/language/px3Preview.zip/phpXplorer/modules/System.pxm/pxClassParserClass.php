<?php
/* Copyright notice */

/**
 * Class data type
 * @access private
 */
class pxClassParserClass
{
	/**
	 * Name of the class
	 * 
	 * @var string
	 */
	var $sName;

	/**
	 * String value after extends keyword
	 * 
	 * @internal Get filled by parser class 
	 * @var string
	 */
	var $sSuperClass;

	/**
	 * Array of pxClassParserVariable objects
	 *  
	 * @var array
	 */
	var $aVariables = array();
	
	/**
	 * Array of pxClassParserFunction objects
	 *  
	 * @var array
	 */	
	var $aFunctions = array();

	/**
	 * Assoc array with tag names as keys and arrays with all occured key values as value
	 * 
	 * @var array 
	 */
	var $aCommentTags = array();
	
	/**
	 * @param string $sName Class name
	 * @param string $sComment Text of previous PHP comment block or null
	 */
	function pxClassParserClass($sName, $sComment)
	{
		$this->sName = $sName;

		$this->aCommentTags = pxClassParser::_splitComment($sComment);
	}

	/**
	 * Add new variable object to variable array.
	 * 
	 * @param integer $iVisibility Valid values T_VAR, T_PUBLIC, T_PROTECTED or T_PRIVATE
	 * @param string $sName Class member name
	 * @param string $sValue Initial value of the class member
	 * @param string $sComment Text of previous PHP comment block or null
	 */
	function addVariable($iVisibility, $sName, $sValue, $sComment)
	{
		$this->aVariables[$sName] =& new pxClassParserVariable($iVisibility, $sName, $sValue, $sComment);
	}

	/**
	 * Add new function/method object to variable array.
	 * 
	 * @param integer $iVisibility Valid values T_VAR, T_PUBLIC, T_PROTECTED or T_PRIVATE
	 * @param string $sName Class member name
	 * @param string $sComment Text of previous PHP comment block
	 */
	function addFunction($iVisibility, $sName, $sComment)
	{
		$this->aFunctions[$sName] =& new pxClassParserFunction($iVisibility, $sName, $sComment);
	}
	
	/**
	 * Returns command tag value
	 * 
	 * @param string $sTag Tag ID
	 * @return mixed Tag value
	 */
	function getTagValue($sTag)
	{
		if (isset($this->aCommentTags[$sTag])) {		
			return $this->aCommentTags[$sTag];
		} else {
			return null;
		}
	}
	
	/**
	 * Returns true or false depending on the existance of $sTag
	 * 
	 * @param string $sTag Tag ID
	 * @return boolean
	 */
	function tagExists($sTag)
	{
		return isset($this->aCommentTags[$sTag]);
	}
}

?>