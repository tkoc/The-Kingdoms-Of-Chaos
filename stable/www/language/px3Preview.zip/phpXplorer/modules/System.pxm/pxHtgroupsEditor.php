<?php
/* Copyright notice */

/**
 * Apache style .htgroups file editor class
 */
class pxHtgroupsEditor
{
	var $aGroups = array();
	var $sFilename = '';
	var $deletedGroups = array();

	var $filePasswd;

	function pxHtgroupsEditor($sFilename)
	{
		if (empty($sFilename)) {
			die('Filename is empty');
		}

		if (!file_exists($sFilename)) {
			die('File "' . $sFilename . '" not found');
		}

		$this->sFilename = $sFilename;
		
		$aLines = file($sFilename);
		
		foreach ($aLines as $sLine) {
			$arr1 = explode(':', $sLine);
			$arr2 = explode(' ', $arr1[1]);

			$this->aGroups[$arr1[0]] = array();

			foreach($arr2 as $item2) {
				array_push($this->aGroups[$arr1[0]], trim($item2));
			}
		}
	}

	function addGroup($sGroupname, $aUsers = array())
	{
		$this->aGroups[$sGroupname] = $aUsers;
		return true;
	}

	function addUser($sGroupname, $sUsername)
	{
		if(!in_array($sUsername, $this->aGroups[$sGroupname]))
			array_push($this->aGroups[$sGroupname], $sUsername);
	}

	function hasGroup($sUsername)
	{
		foreach ($this->aGroups as $sKey => $aValues) {
			if (in_array($sUsername, $aValues)) {
				return true;
			}
		}
		return false;
	}

	function deleteUser($sUsername)
	{
		foreach ($this->aGroups as $sKey => $aValues) {
			if (in_array($sUsername, $aValues)) {
				for ($i = 0, $m = count($this->aGroups[$sKey]); $i < $m; $i++) {
					if ($this->aGroups[$sKey][$i] == $sUsername) {
						unset($this->aGroups[$sKey][$i]);
					}
				}
			}
		}
	}

	function deleteGroup($sGroupname)
	{
		$this->aGroups[$sGroupname] = array();
		return true;
	}

	function writeFile()
	{
		global $pxp;

		$pxp->oVfs->file_put_contents($this->sFilename, $this->getCode());
	}

	function getCode()
	{
		$content = '';

		foreach($this->aGroups as $sKey => $aValues) {
			if (!empty($aValues)) {
				$content .= $sKey . ":" . implode(' ', $aValues) . "\n";
			}
		}
		return $content;
	}
}

?>