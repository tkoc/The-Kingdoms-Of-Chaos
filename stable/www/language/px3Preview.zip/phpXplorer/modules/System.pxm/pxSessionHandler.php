<?php

class SessionHandler
{
	var $sData = '';
	var $sName;
	var $sPath;

	function open($sPath, $sName) {
		$this->sPath = $sPath;
		$this->sName = $sName;
		return(true);
	}

	function close() {
		return(true);
	}

	function read($sId) {
		$sFile = $this->sPath . '/sess_' . $sId;
		if ($fp = @fopen($sFile, 'r')) {
			$this->sData = fread($fp, filesize($sFile));
			return($this->sData);
		} else {
			return(''); // Must return '' here.
	  }
	}

	function write($sId, $sData) {
		$sFile = $this->sPath . '/sess_' . $sId;
		if ($this->sData != $sData) {
			if ($fp = fopen($sFile, 'w')) {
				flock($fp, LOCK_EX);
				$sResult = fwrite($fp, $sData);
				flock($fp, LOCK_UN);
				return($sResult);
			} else {
				return(false);
			}
		}
	}

	function destroy($sId) {
		$sFile = $this->sPath . '/sess_' . $sId;
		return(unlink($sFile));
	}

	/************************************************
	 * WARNUNG - Sie m�ssen hier irgendeine Art von *
	 * Speicherbereinigungsroutine realisieren.    *
	 ************************************************/
	function gc($maxlifetime) {
		return true;
	}
}

$oSessionHandler = new SessionHandler();

session_set_save_handler(
	array($oSessionHandler, 'open'),
	array($oSessionHandler, 'close'),
	array($oSessionHandler, 'read'),
	array($oSessionHandler, 'write'),
	array($oSessionHandler, 'destroy'),
	array($oSessionHandler, 'gc')
);

?>