px.Class.define('px.ui.tabview.Button',
{
	extend: px.core.Object,

	construct: function(oParent, sId, sTitle)
	{
		this.oParent = oParent
		this.sId = sId
		this.sTitle = sTitle
		this.oDiv = document.createElement('div')
		this.oDiv.className = 'pxTab'

		this.oDiv.appendChild(document.createTextNode(sTitle))

		if (this.oParent.oInsertBefore) {
			this.oParent.oParentNode.insertBefore(this.oDiv, this.oParent.oInsertBefore)
		} else {
			this.oParent.oParentNode.appendChild(this.oDiv)
		}

		this.oDiv.onclick = px.lang.Function.bind(this.click, this)
	},
	
	destruct: function() {
		this.oDiv.onclick = null
		this._disposeFields('oParent', 'oDiv')
	}
})

Object.extend(
	px.Proto,
	{
		click: function() {
			this.oParent.setSelected(this.sId)
		}
	}
)