px.Class.define('px.action.pxGlobal___openXplorerview',
{
	extend: px.Action,

	construct: function(sId, oParent, oParentNode, oParameters)
	{
		this.base(arguments, sId, oParent, oParentNode)

		this.oChild = new px.ui.xplorerview.Xplorerview(this)
		var oChild = this.oChild

		oChild.oParameters.set(oParameters)
		oChild.oParameters.sShare = this.oShare.sId
		oChild.bSelection = false
		oChild.onNodeClick = px.lang.Function.bind(this._onNodeClick, this)
		
		oChild.oObject = {
			aEvents: [],
			aPermissions: [],
			aParameters: []
		}

		oChild.init(this.oDiv, true)
	}
})

Object.extend(
	px.Proto,
	{
		_onNodeClick: function(oNode)
		{
			var oEditorview = pxp.oShareview.oSelected.oActionviewFiles
			var sPath = 'px:xplorerview'

			var sType = oNode.sId
			var iPos = sType.indexOf('.')
			if (iPos > -1) {
				sType = sType.substr(0, iPos)
			}

 			if (!oEditorview.oActions[sPath]) {
 				oEditorview.addAction(
 					sPath,
 					'xplorer',
 					px.action.pxGlobal___openEditorview,
 					true,
					'types/pxType',
	 				{
	 					sShare: 'kpw3',
						sPath: '/css.php',
						sType: 'pxType',
	 					_sCalledAction: 'pxObject_editProperties'
	 				}
 				)
 			}

 			oEditorview.showAction(sPath)
 			
 			oEditorview.oSelected.oChild.oSelected.show(sType)
		}
	}
)