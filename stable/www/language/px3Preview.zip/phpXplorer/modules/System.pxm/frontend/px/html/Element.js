px.Class.define('px.html.Element')

Object.extend(
	px.Statics,
	{
		addClassName: function(oElement, sClass) {
			var aClasses = oElement.className.split(/\s+/)
			if (!px.lang.Array.contains(aClasses, sClass)) {
				aClasses.push(sClass)
				oElement.className = aClasses.join(' ')
			}
		},

		removeClassName: function(oElement, sClass) {
			var aClasses = oElement.className.split(/\s+/)
			px.lang.Array.remove(aClasses, sClass)
			oElement.className = aClasses.join(' ')
		},

		hasClassName: function(oElement, sClass) {
			var aClasses = oElement.className.split(/\s+/)
			return px.lang.Array.contains(aClasses, sClass)
		},

		appendImage: function(oNode, sSrc, oInsertBefore, iSize, sClass)
		{
			var oImage = new Image()

			if (pxp.bIe && sSrc.indexOf('.png') > -1) {
				oImage.src = pxConst.sGraphicUrl + '/dummy.png'
				oImage.style.filter = pxConst.ALPHA_IMAGE_START + sSrc + pxConst.ALPHA_IMAGE_STOP
			} else {
				oImage.src = sSrc
			}

			if (iSize) {
				oImage.style.width = iSize + 'px'
				oImage.style.height = iSize + 'px'
			}

			if (sClass) {
				oImage.className = sClass
			}

			if (oInsertBefore) {
				return oNode.insertBefore(oImage, oInsertBefore)
			} else {
				return oNode.appendChild(oImage)
			}
		},

		changeImage: function(oImage, sSrc) {
			if (pxp.bIe && sSrc.indexOf('.gif') == -1) {
				oImage.style.filter = pxConst.ALPHA_IMAGE_START + sSrc + pxConst.ALPHA_IMAGE_STOP
			} else {
				oImage.src = sSrc
			}
		},
		
		getLeftOffset: function(oNode, oUpperNode) {
			var x = 0
			for (var o=oNode; o; o=o.offsetParent) {
				x += o.offsetLeft
				if (oUpperNode && o == oUpperNode) {
					break
				}
			}
			return x
		},

		getTopOffset: function(oNode, oUpperNode) {
			var x = 0
			for (var o=oNode; o; o=o.offsetParent) {
				x += o.offsetTop
				if (oUpperNode && o == oUpperNode) {
					break
				}
			}
			return x
		},

		hideElements: function(sElement) {
			var oNodes = document.getElementsByTagName(sElement)
			for (var n=0; n<oNodes.length; n++) {
				oNodes[n].style.visibility = 'hidden'
			}
		},

		showElements: function(sElement) {
			var oNodes = document.getElementsByTagName(sElement)
			for (var n=0; n<oNodes.length; n++) {
				if (oNodes[n].style.visibility) {
					oNodes[n].style.visibility = ''
				}
			}
		},

	  hide: function(oElement) {
	    oElement.style.display = 'none'
	  },

	  show: function(oElement) {
	    oElement.style.display = ''
	  },
	  
	  switchElement: function(oElement) {
	  	oElement.style.display =
	  		oElement.style.display == 'none' ? '' : 'none'
	  },
	  
	  setOpacity: function(oElement, iAlpha)
	  {
			var oStyle = oElement.style
			
			if (oStyle.MozOpacity != undefined ) {
				oStyle.MozOpacity = iAlpha
			}
			else if (oStyle.filter != undefined ) {
				oStyle.filter = 'alpha(opacity=0)'
				oElement.filters.alpha.opacity = iAlpha * 100
			}
			else if (oStyle.opacity != undefined ) {
				oStyle.opacity = iAlpha
			}
		}
	}
)