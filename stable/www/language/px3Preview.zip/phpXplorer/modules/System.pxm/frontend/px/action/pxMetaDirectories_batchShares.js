px.Class.define('px.action.pxMetaDirectories_batchShares',
{
	extend: px.action.pxDirectories___open,

	construct: function(sId, oParent, oParentNode, oParametersIn)
	{
		//this.oParent = oParent
			
		this.base(arguments, sId, oParent, oParentNode, oParametersIn, px.ui.listview.Listview)

		var oList = this.oChild
		var oParam = oList.oParameters

		oParam.sShare = this.oShare.sId
		oParam.bFull = true
		oParam.bFillOptions = true
		oParam.bRecursiveFlat = true
		oParam.aTypes = Array('pxUser')

		oList.addColumn('sName', 250, 'link', 'left')
		oList.addColumn('sRelDir', 200, 'text', 'left')
		oList.addColumn('aRoles', 200, 'multiple', 'left')

		oList.update()
	}
})