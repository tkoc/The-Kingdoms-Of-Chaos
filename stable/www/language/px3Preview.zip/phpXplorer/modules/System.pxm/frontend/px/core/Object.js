px.Class.define('px.core.Object',
{
	extend : Object,
	destruct: function()
	{
//		alert("destruct object")
	}
})

Object.extend(
	px.Statics,
	{
		dispose: function() {
			for (var i in this) {
				switch (typeof this[i]) {
					case undefined:
					case 'object':
					case 'function':
						delete this[i]
					break;
				}
			}
		}
	}
)

Object.extend(
	px.Proto,
	{
		base: function(args)
		{
		  if (arguments.length === 1) {
		    return args.callee.base.call(this)
		  } else {
		    return args.callee.base.apply(this, Array.prototype.slice.call(arguments, 1))
		  }
		},
		
		dispose: function()
		{
      if (this.__bDisposed) {
      	alert(this.classname +  ' already disposed')
        return
      }

      this.__bDisposed = true
      
      pxp.log('Dispose ' + this.classname)

			var clazz = this.constructor

			while (clazz.superclass) {
				if (clazz.$$destructor) {
					clazz.$$destructor.call(this);
				}
				clazz = clazz.superclass;
			}

			if (px.dev) {
				px.dev.MemoryLeak.check(this)
			}
		},

		_disposeFields: function()
		{
			for (var i=0, l=arguments.length; i<l; i++)
			{
				var sName = arguments[i]				
				if (this[sName] == null) {
					continue
				}

				if (!this.hasOwnProperty(sName)) {
					alert(this.classname + " has no own field " + name)
					continue
				}

				this[sName] = null
      }
    },

		_disposeObjects: function()
		{
			for (var i=0, l=arguments.length; i<l; i++)
			{
				var sName = arguments[i]
				if (this[sName] == null) {
					continue
				}

				if (!this.hasOwnProperty(sName)) {
					alert(this.classname + " has no own field " + name)
					continue
				}

				this[sName].dispose()
				this[sName] = null
  		}
		},

		_disposeContents: function()
		{
			for (var i=0, l=arguments.length; i<l; i++)
			{
				var sName = arguments[i]
				if (this[sName] == null) {
					continue
				}

				if (!this.hasOwnProperty(sName)) {
					alert(this.classname + " has no own field " + name)
					continue
				}

				if (this[sName] instanceof Array) {
					for (var i2=0, l2=this[sName].length; i2<l2; i2++) {
						this[sName][i2].dispose()
						this[sName][i2] = null
					}
				} else if (this[sName] instanceof Object) {
					for (var sKey in this[sName]) {
						this[sName][sKey].dispose()
						this[sName][sKey] = null
					}
				}

				this[sName] = null
  		}
		}
	}
)