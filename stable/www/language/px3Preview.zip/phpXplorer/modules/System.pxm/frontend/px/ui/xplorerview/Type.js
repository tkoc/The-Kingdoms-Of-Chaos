px.Class.define('px.ui.xplorerview.Type',
{
	extend: px.ui.xplorerview.Item,

	construct: function(sId, oParent, oParentNode)
	{
		this.bGroupsRendered = this.bGroupsExpanded= false

		this.base(arguments,
			sId,
			oParent,
			oParentNode,
			pxp.oTypes[sId].bAbstract ? 'pxAbstract.png' : 'pxType.png',
			sId
		)
	}
})

Object.extend(
	px.Proto,
	{
		hasChildren: function()
		{
			for (var sType in pxp.oTypes) {
				if (pxp.oTypes[sType].sSupertype == this.sId) {
					return true
				}
			}
			return false
		},

		expandGroups: function()
		{
			if (this.bGroupsRendered) {
				this.bGroupsExpanded = !this.bGroupsExpanded
			} else {
				var aGroups = {}
				for (var a=0, m=pxp.oTypes[this.sId].aActions.length; a<m; a++) {
					aGroups[pxp.oActions[pxp.oTypes[this.sId].aActions[a]][2]] = true
				}
				for (var sBaseAction in aGroups) {
					var sId = this.sId + '.' + sBaseAction
					this.oParent.oItems[sId] = new px.ui.xplorerview.Actiongroup(sId, this.oParent, this.oDivActionGroups)
				}
				this.bGroupsRendered = this.bGroupsExpanded = true
			}
			
			this.oDivActionGroups.style.display = this.bGroupsExpanded ? '' : 'none'
			this.oExpandImage2.src = pxConst.sGraphicUrl + (this.bGroupsExpanded ? '/collapse.png' : '/expand.png')	
		}		
	}
)
