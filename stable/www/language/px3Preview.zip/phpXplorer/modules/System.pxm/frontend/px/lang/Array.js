px.Class.define('px.lang.Array')

Object.extend(
	px.Statics,
	{
		remove: function(aArray, mItem) {
			for (var i=0, l=aArray.length; i<l; i++) {
				if (aArray[i] == mItem) {
					aArray.splice(i, 1)
					break
				}
			}
		},
		
		contains: function(aArray, mItem) {
			if (aArray.length) {
				for (var i=0; i<aArray.length; i++) {
					if (aArray[i] == mItem) {
						return true
					}
				}
			}
			return false			
		}
	}
)