px.Class.define('px.ui.listview.Column',
{
	extend: px.core.Object,
  
  construct: function(oParent, sId, iWidth, sType, sAlign, oFormat, bTemp)
  {
		this.oParent = oParent
		this.sId = sId
		this.iWidth = iWidth
		this.sType = sType
		this.sAlign = sAlign
		this.oFormat = oFormat
		this.bTemp = bTemp
		this.oTh
	},

	destruct: function()
	{
		var oTh = this.oTh
		if (oTh) {
			oTh.onmousemove = null
			oTh.onmousedown = null
			oTh.onmouseup = null
			oTh.onmouseover = null
			oTh.onmouseout = null
		}
		this._disposeFields('oParent', 'oFormat', 'oTh')
	}
})

Object.extend(
	px.Statics,
	{
		//oActiveItem: null, ???

		resize: function(oEvent) {
			var oEvent = oEvent || window.event
			var iWidth = oEvent.clientX - px.html.Element.getLeftOffset(oActiveItem) + pxp.oSelectedControl.oParentNode.scrollLeft
			if (iWidth < 8) {
				iWidth = 8
			}
			pxp.oSelectedControl.oColumns[oActiveItem.id.substr(oActiveItem.id.indexOf('_') + 1)]['iWidth'] = iWidth
			oActiveItem.style.width = iWidth + 'px'
		},

		move: function(oEvent)
		{
			var oEvent = oEvent || window.event
			var iLeft = oEvent.clientX - iDragOffset
			var oSel = pxp.oSelectedControl
			var iPos = oSel.bChecklist ? 2 : 1

			var oDragColumn = $('dragColumn')
			if (!oDragColumn) {
				var oDragColumn = document.createElement('div')
				oDragColumn.id = 'dragColumn'
				oDragColumn.appendChild(document.createTextNode(oActiveItem.firstChild.nodeValue))
				document.body.appendChild(oDragColumn)
			} else {
				oDragColumn.firstChild.nodeValue = oActiveItem.firstChild.nodeValue
			}
			
			oDragColumn.style.width = oActiveItem.style.width
			oDragColumn.style.top = px.html.Element.getTopOffset(oActiveItem) + 'px'
		
			if (iLeft > 0)
				oDragColumn.style.left = iLeft + 'px'
		
			oDragColumn.style.display = ''
		
			var aHeaders = oSel._oTableHead.firstChild.childNodes
		
			for (var i=iPos; i<aHeaders.length; i++)
			{
				var oHeader = aHeaders[i]
				var iLeftOffset = px.html.Element.getLeftOffset(oHeader)

				if (iLeft > iLeftOffset && iLeft < (iLeftOffset + oHeader.offsetWidth)) {
					if (oActiveItem != oHeader && oActiveItem.nextSibling != oHeader) {
						if (oHeader.className != 'drop') {
							oHeader.className = 'drop'
						}
					}
				} else {
					if (oHeader.className != null) {
						oHeader.className = null
					}
				}
			}
			oDragColumn = null	
		}
	}
)

Object.extend(
	px.Proto,
	{
		headerMouseOver: function(oEvent) {
			oEvent.cancelBubble = true
			if (document.onmousemove == null) {
				this.oTh.className = 'over'
			}
		},

		headerMouseOut: function(oEvent) {
			if (pxp.bDragging) {
				return
			}
			this.oTh.className = null
		},

		headerMouseMove: function(oEvent)
		{
			if (pxp.bDragging) {
				return
			}

			var cElement = px.html.Element
			var iOffsetLeft = cElement.getLeftOffset(this.oTh)
			var iRange = iOffsetLeft + this.oTh.offsetWidth - oEvent.clientX - this.oParent.oParentNode.scrollLeft

			if (iRange < 16) {
				this.oTh.style.cursor = 'e-resize'
				px.ui.listview.Listview.bHeaderEdgeOver = true
			} else {
				this.oTh.style.cursor = 'move'
				iDragOffset = oEvent.clientX - cElement.getLeftOffset(this.oTh)
				delete px.ui.listview.Listview.bHeaderEdgeOver
			}

			oActiveItem = this.oTh
		},
		
		headerMouseDown: function(oEvent)
		{
			this.oParent.oActiveItem = this
			pxp.setActiveControl(this.oParent)

			pxp.startDrag('listviewColumn')

			if (px.ui.listview.Listview.bHeaderEdgeOver) {
				document.onmousemove = px.ui.listview.Column.resize
			} else {
				document.onmousemove = px.ui.listview.Column.move
			}
		},
		
		headerMouseUp: function(oEvent) {
			if (!px.ui.listview.Listview.bHeaderEdgeOver) {
				this.oParent.sort(this.sId)	
			}
		}
	}
)