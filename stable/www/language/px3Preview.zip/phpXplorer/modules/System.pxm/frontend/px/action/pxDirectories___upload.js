px.Class.define('px.action.pxDirectories___upload')

Object.extend(
	px.Statics,
	{
		run: function(oObject, sActionIn)
		{
			var sShare = pxp.oShareview.oSelected.oShare.sId
			var oView = pxp.getListview()
			var sPath = oView.oParameters.sPath
			var sAction = sActionIn || 'uploadHtml'
	
			if (oObject.bControl) {
				for (var sFileName in oView.oSelected) {
					//sPath = px.util.buildPath(
					//	sPath,
					//	sFileName
					//)
					sPath = sFileName
					break
				}
			}

			var iTop = (document.body.offsetHeight / 2) - 240
			var iLeft = (document.body.offsetWidth * 0.4) - 320
	
			var oWin = window.open(
				'./action.php?sShare=' + sShare + '&sAction=' + sAction + '&sPath=' + encodeURIComponent(sPath),
				px.util.getRandomId(),
				'top=' + iTop + ',left=' + iLeft + ',width=640,height=480,scrollbars=yes,resizable=yes'
			)

			return false
		}
	}
)