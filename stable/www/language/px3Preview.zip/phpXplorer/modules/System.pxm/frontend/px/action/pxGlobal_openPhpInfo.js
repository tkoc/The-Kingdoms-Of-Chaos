px.Class.define('px.action.pxGlobal_openPhpInfo')

Object.extend(
	px.Statics,
	{
		run: function()
		{
			window.open(
				'./action.php?sShare=phpXplorer&sAction=openPhpInfo',
				px.util.getRandomId(),
				'toolbar=no,location=yes,menubar=yes,resizable=yes,scrollbars=yes'
			)
		}
	}
)