px.Class.define('px.action.pxGlobal_openLogin')

Object.extend(
	px.Statics,
	{
		oLoginview: null,
	
		run: function()
		{			
			this.oLoginview = new px.ui.Actionview()
			this.oLoginview.sClass = 'loginBar'
			this.oLoginview.iMenuType = pxConst.MENU_TABS

			this.oLoginview.addAction(
				'login',
				oTranslation['action.pxGlobal_openLogin'],
				px.action.pxGlobal_openLoginForm,
				true
			)
			
			/*
			this.oLoginview.addAction(
				'register',
				'Neuanmeldung',
				px.action.pxGlobal_openLoginForm
			)
			*/

			this.oLoginview.init($('loginContainer'))
		},

		dispose: function() {
			this.oLoginview.dispose()
		},
	
		login: function(oEvent) {
			//if (oEvent && oEvent.keyCode != 13) {
			//	return
			//}
			document.forms[0].submit()
		},
	
		guestLogin: function() {
	  	var oForm = document.forms[0]
	  	oForm.pxAuthUser.value = 'everyone'
	  	oForm.pxAuthPassword.value = 'everyone'
	  	px.action.pxGlobal_openLogin.login()
		},
		
		signup: function() {
			location.href = './action.php?sAction=pxGlobal_editProfile'
		}
	}
)

px.Event.addListener(window, 'load', px.lang.Function.bind(px.action.pxGlobal_openLogin.run, px.action.pxGlobal_openLogin))