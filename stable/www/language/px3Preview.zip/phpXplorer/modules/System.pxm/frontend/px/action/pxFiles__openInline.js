px.Class.define('px.action.pxFiles__openInline',
{
	extend: px.Action,

	construct: function(sId, oParent, oParentNode, oParameters)
	{
		this.base(arguments, sId, oParent, oParentNode)

		this.oDiv.style.overflow = 'hidden'

		this.oIframe = document.createElement('iframe')
		this.oIframe.border = 0
		this.oIframe.frameBorder = 0

		this.oDiv.appendChild(this.oIframe)

		var sPath = oParameters ? oParameters.sPath : 'dummy.php'

		if (this.oShare) {
			this.oIframe.src = px.util.buildPath(this.oShare.sUrl, sPath)
		} else {
			this.oIframe.src = sPath
		}
	},

	destruct: function() {
		this._disposeFields('oIframe')
	}
})

Object.extend(
	px.Proto,
	{
		_resizeStart: function() {
			if (this.oIframe) {
				px.html.Element.hide(this.oIframe)
			}
		},

		_resizeStop: function() {
			if (this.oIframe)
			px.html.Element.show(this.oIframe)
		}
	}
)