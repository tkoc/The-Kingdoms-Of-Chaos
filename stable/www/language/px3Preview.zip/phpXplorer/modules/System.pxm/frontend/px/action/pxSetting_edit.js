px.Class.define('px.action.pxSetting_edit',
{
	extend: px.action.pxObject___edit,

	construct: function(sId, oParent, oParentNode, oParameters)
	{
		this.base(arguments, sId, oParent, oParentNode, oParameters)

		this.oXplorerview = new px.ui.xplorerview.Xplorerview(this)
		this.oXplorerview.oParameters.set(oParameters)
		this.oXplorerview.oParameters.sShare = this.oShare.sId
		this.oXplorerview.onNodeClick = px.lang.Function.bind(this._onNodeClick, this)

		this.oXplorerviewPropertyview = new px.ui.xplorerview.Propertyview(this)

		this.oSplitview = new px.ui.Splitview(true, 0.4)
		this.oChild = this.oSplitview
		this.oChild2 = this.oXplorerview

		this.oChild.oChild1 = this.oXplorerview
		this.oChild.oChild2 = this.oXplorerviewPropertyview
		this.oChild.bSnap = false

		this.oChild.init(this.oDiv)

//		for (var i in pxp.oTypes['pxMeta']) {
//			alert(i + ': ' + pxp.oTypes['pxMeta'][i])
//		}

	},

	destruct: function() {
		this._disposeFields(
			'oSplitview', 'oXplorerview', 'oXplorerviewPropertyview', 'oChild2'
		)
	}
})

Object.extend(
	px.Proto,
	{
		_onNodeClick: function(oNode)
		{
			var oView = oNode.oParent
			var oPropertyView = oView.oParent.oXplorerviewPropertyview
			var sEvent = oView.oObject.aEvents[oNode.sId]
			oPropertyView.oEvent.value = sEvent || ''
		}
	}
)