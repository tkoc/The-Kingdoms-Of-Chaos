px.Class.define('px.action.pxGlobal_openCreate')

Object.extend(
	px.Statics,
	{
		run: function(sType, sNewName)
		{
			var sAction = sType + '__editCreate'

			if (px.action[sAction] && px.action[sAction].run) {
				px.action[sAction].run()
				return
			}

			var oType = pxp.oTypes[sType]

			if (!sNewName) {
				var sNewName = ''
				if (sType != 'pxData') {
					sNewName = (oType.bDirectory ? oTranslation['newDirectory'] : oTranslation['newFile']) + ' ' + pxp.iNewFileCount++
				}
				sNewName = pxp.addValidExtension(sNewName, sType)
			}

			var oListview = pxp.getListview()
			var sPath = oListview.oParameters.sPath
			var sFullPath = px.util.buildPath(sPath, sNewName)

			var oView = pxp.oShareview.oSelected.oActionviewFiles
 			if (!oView.oActions[sFullPath]) {
 				oView.addAction(
 					sFullPath,
					sFullPath.indexOf('/') == 0 ? sFullPath.substr(1) : sFullPath,
 					px.action.pxGlobal___openEditorview,
 					true,
					'types/' + sType,
	 				{
	 					sPath: sFullPath,
	 					sType: sType,
						_bNew: true,
						sNewName: sNewName
	 				}
 				)
 			}
 			oView.showAction(sFullPath)
		},

		showMenu: function(oEvent)
		{
			pxp.setActiveControl(px.action.pxGlobal_openCreate)
	
			var sShare = this.oParent.oParent.sId
			var sPath = this.oChild.oParameters.sPath
					
			var aTypes = px.io.Request.get('sAction=openCreate&sShare=' + encodeURIComponent(sShare) + '&sPath=' + encodeURIComponent(sPath))
	
			var oCm = px.ui.ContextMenu
			oCm.clear()
	
			for (var t=0; t<aTypes.length; t++)
			{
				var oType = pxp.oTypes[aTypes[t]]
				var sExtendedType = pxp.getExtendedType(oType.sId)
	
				oCm.addItem(
					oType.sId,
					oTranslation['type.' + sExtendedType],
					'./modules/' + oType.sModule + '.pxm/graphics/types/' + sExtendedType + '.png'
				)
			}
			oCm.show(oEvent)
	
			return false
		},

		callAction: function(sAction) {
			this.run(sAction)
		}
	}
)