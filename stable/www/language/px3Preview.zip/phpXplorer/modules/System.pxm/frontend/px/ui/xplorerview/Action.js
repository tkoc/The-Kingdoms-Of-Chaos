px.Class.define('px.ui.xplorerview.Action',
{
	extend: px.ui.xplorerview.Item,

	construct: function(sId, oParent, oParentNode)
	{
		this.base(arguments,
			sId,
			oParent,
			oParentNode,
			'pxAction.png',
			oTranslation['action.' + sId.split('.')[2]]
		)
	}
})

Object.extend(
	px.Proto,
	{
		hasChildren: function() {
			return false
		}
	}
)