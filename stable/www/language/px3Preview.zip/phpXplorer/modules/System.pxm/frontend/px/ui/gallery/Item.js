px.Class.define('px.ui.gallery.Item',
{
	extend: px.ui.ListItem,

	construct: function() {
		this.iIndex
		this.oDiv
		this.oParent
		this.sFilename
		this.bDirectory
		this.oNameNode
	},

	destruct: function() {		
		var oDiv = this.oDiv
		oDiv.onclick = null
		oDiv.onmousedown = null
		oDiv.onmouseover = null
		oDiv.onmouseout = null
		oDiv.onmouseup = null
		oDiv.ondblclick = null
		
		//px.dev.MemoryLeak.check(oDiv)
		
		this.oNameNode.onclick = null
		this._disposeFields('oParent', 'oDiv', 'oImage', 'oNameNode')
	}
})

Object.extend(
	px.Proto,
	{
		selectItem: function(oEvent, bDrag) {
			var oParent = this.oParent
			if (oEvent.ctrlKey || bDrag) { 
				if (oParent.oSelected[this.sFilename] && !bDrag) {
					delete oParent.oSelected[this.sFilename]
				} else {
					oParent.oSelected[this.sFilename] = this
				}
			} else {
				oParent.oSelected = {}
				oParent.oSelected[this.sFilename] = this
			}
			oParent.setSelection()
		},
		
		itemMouseOver: function(oEvent)
		{
			oEvent.cancelBubble = true
			
			if (pxp.bIe) {
				px.html.Element.addClassName(this.oNameNode, 'hover')
			}
			if (
				pxp.bDragging &&
				this.bDirectory &&
				pxp.sDragType == 'item' &&
				!pxp.oSelectedControl.oSelected[this.sFilename] &&
				this.sFilename.indexOf(pxp.oSelectedControl.oActiveItem.sFilename) != 0 &&
				this.getType() != 'pxVirtualDirectory'
			) {
				this.oNameNode.className = 'drop'
			}
		},
		
		itemMouseOut: function() {
			if (pxp.bIe) {
				px.html.Element.removeClassName(this.oNameNode, 'hover')
			}
			px.html.Element.removeClassName(this.oNameNode, 'drop')
		},
		
		itemMouseUp: function(oEvent) {
			if (px.html.Element.hasClassName(this.oNameNode, 'drop')) {
				px.action.pxObject_editClipboard.itemDrop(this)
			}
		}
	}
)