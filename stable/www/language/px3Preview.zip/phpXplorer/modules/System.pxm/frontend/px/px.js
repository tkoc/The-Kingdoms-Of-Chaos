Object.extend = function(destination, source) {
  for (var property in source) {
    destination[property] = source[property];
  }
  return destination;
}

var px =
{
	action: {},
	util: {},
	ui: {},
	io: {},

	Proto: null,
	Statics: null,
	Class:
	{
		__registry : {},

		define: function(sPath, oConfig)
		{	
			var oClass

			if (!oConfig) {
				oConfig = {}
			}

			if (oConfig.construct) {
				oClass = oConfig.construct
			} else {
				oClass = function() {}
			}

			this.createNamespace(sPath, oClass)

			if (oConfig.extend) {

        var oHelper = function(){}
        oHelper.prototype = oConfig.extend.prototype
        var oProto = new oHelper

        oClass.prototype = oProto

				oClass.base = oClass.superclass = oConfig.extend

				oProto.constructor = oClass
			}
			
			if (oConfig.destruct) {
				oClass.$$destructor = oConfig.destruct
			}

			oClass.classname = oClass.prototype.classname = sPath;

			//oClass.prototype.classname = 

			/*
					for (var sKey in oConfig.statics) {
						oClass[sKey] = oConfig.statics[sKey]
					}
					for (var sKey in oConfig.members) {
						oClass.prototype[sKey] = oConfig.members[sKey]
					}
			*/

				px.Statics = oClass
				px.Proto = oClass.prototype

				//this.__registry[sPath] = oClass

				return oClass
		},
		
		createNamespace: function(sPath, oObject)
		{
			var aParts = sPath.split('.')
			var parent = window
			var sPart = aParts[0]
			
			for (var i=0, m=aParts.length-1; i<m; i++, sPart=aParts[i])
			{
				if (!parent[sPart]) {
					parent = parent[sPart] = {}
				} else {
					parent = parent[sPart]
				}
			}
			
			if (parent[sPart] != undefined) {
				alert('An object of the name "' + name + '" aready exists')
			}
			
			parent[sPart] = oObject

			return sPart
		}
	}
}