px.Class.define('px.action.pxMetaDirectories_openDetails',
{
	extend: px.action.pxDirectories___open,

	construct: function(sId, oParent, oParentNode, oParametersIn)
	{
		//this.oParent = oParent

		this.base(arguments, sId, oParent, oParentNode, oParametersIn, px.ui.listview.Listview)

		var oList = this.oChild

		oList.oParameters.sShare = this.oShare.sId

		oList.addColumn('sName', 250, 'link', 'left')
		oList.addColumn('iBytes', 70, 'text', 'right', px.util.Format.number)
		oList.addColumn('dModified', 140, 'text', 'left', px.util.Format.datetime)
		oList.addColumn('sType', 140, 'type', 'left')


//  	oList.oParameters.bFull = true
//		oList.oParameters.bFillOptions = true

//		oList.addColumn('sLanguage', 140, 'select', 'left')


		oList.update()		
	}
})