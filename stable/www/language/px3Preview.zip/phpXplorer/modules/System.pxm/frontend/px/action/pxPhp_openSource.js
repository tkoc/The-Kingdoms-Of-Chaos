px.Class.define('px.action.pxPhp_openSource')

Object.extend(
	px.Statics,
	{
		run: function(oView) {
			px.action.pxMetaFiles_openView.run(oView, 'openSource')
		}
	}
)