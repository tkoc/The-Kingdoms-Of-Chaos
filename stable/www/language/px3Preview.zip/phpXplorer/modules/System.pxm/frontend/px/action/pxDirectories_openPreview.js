px.Class.define('px.action.pxDirectories_openPreview',
{
	extend: px.action.pxDirectories___open,

	construct: function(sId, oParent, oParentNode, oParametersIn)
	{
		//this.oParent = oParent
		
		this.base(arguments, sId, oParent, oParentNode, oParametersIn, px.ui.gallery.Galleryview)

		var oGallery = this.oChild
  	oGallery.oParameters.sShare = this.oShare.sId
		oGallery.update()
	}
})