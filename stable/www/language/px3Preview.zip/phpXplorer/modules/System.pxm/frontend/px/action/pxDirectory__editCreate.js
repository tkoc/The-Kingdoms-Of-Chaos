px.Class.define('px.action.pxDirectory__editCreate')

Object.extend(
	px.Statics,
	{
		run: function(sNewType, sNewName, bRetype, bRaiseError)
		{
			if (!sNewType) {
				var sNewType = 'pxDirectory'
			}

			var oList = pxp.getListview()
			var sShare = oList.oParameters.sShare
			var sDir = oList.oParameters.sPath
	
			if (!sNewName || bRetype) {
				var sNewName = px.util.getNewFilename(sNewName, 'pxDirectory', true)
				if (sNewName == null) {
					return false
				}
			}

			var sPath = px.util.buildPath(sDir, sNewName)

			var oResult = px.io.Request.exists(sShare, sPath)
			if (oResult.bOk) {
				if (!bRaiseError && bRaiseError != false) {
					alert(oTranslation['error.objectExists'])
					px.action.pxDirectory__editCreate.run(sNewType, sNewName, true)
				}
				return false
			}

			var oResult = px.io.Request.post(
				'sShare=' + encodeURIComponent(sShare) +
				'&sAction=_editCreate' +
				'&sPath=' + encodeURIComponent(sPath) + 
				'&sType=' + encodeURIComponent(sNewType)
			)

			if (oResult.bOk) {
				pxp.refreshView(sDir)
			}

			return false
		}	
	}
)