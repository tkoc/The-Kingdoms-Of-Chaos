px.Class.define('px.action.pxMetaFiles_openView')

Object.extend(
	px.Statics,
	{
		run: function(oView, sAction)
		{
			for (var sSelected in oView.oSelected) {
				var oItem = oView.oSelected[sSelected]
				window.open(
					'./action.php?sShare=' +
						oView.oParent.oShare.sId +
						'&sAction=' + (sAction || 'openView') + '&sPath=' +
						encodeURIComponent(oItem.sFilename),
					px.util.getRandomId(),
					'toolbar=no,location=yes,menubar=yes,resizable=yes,scrollbars=yes'
				)
			}
			return false
		}
	}
)