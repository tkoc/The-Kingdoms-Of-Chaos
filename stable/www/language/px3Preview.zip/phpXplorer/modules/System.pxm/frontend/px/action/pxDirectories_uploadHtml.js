px.Class.define('px.action.pxDirectories_uploadHtml')

Object.extend(
	px.Statics,
	{
		sInputId: 'file_input',

		run: function(oObject) {
			px.action.pxDirectories___upload.run(oObject)
			return false
		},
		
		changeMethod: function(oSelect) {
			location.href = './action.php?' + oSelect.options[oSelect.selectedIndex].value
		},

		addFileInput: function()
		{
			var oContainer = $('file_attach')
			var oNewInput = document.createElement('input')
			oNewInput.setAttribute('type', 'file')
			oNewInput.setAttribute('name', 'aFiles[]')
			oNewInput.setAttribute('class', 'upload')
			oNewInput.className = 'upload'
		
			oNewInput.onchange = function() {
				px.action.pxDirectories_uploadHtml.attachFile(this)
			}

			var random = Math.random()
			var random = random * 10
			oNewInput.setAttribute('id', 'file_' + random)
			this.sInputId = 'file_' + random

			$('submitButton').disabled = false

			return oContainer.appendChild(oNewInput)
		},

		hideInput: function() {
			var oInput = document.getElementById(this.sInputId)
			if (oInput.value != '') {
				oInput.style.display = 'none'
				this.addFileToList()
				return true
			} else {
				return false
			}
		},

		addFileToList: function() {
			var oInput = $(this.sInputId)
			var oContainer = $('aFileSelection')
			var newOption = document.createElement('option')
			var newOptionText = document.createTextNode(oInput.value)
			newOption.appendChild(newOptionText)
			oContainer.appendChild(newOption)
		},

		fileExists: function(sNewFile) {
			var aOptions = document.forms[0].aFileSelection.options
			for (var i=0; i<aOptions.length; i++) {
				if (aOptions[i].text == sNewFile) {
					return true
				}
			}
			return false
		},

		removeSelectedFile: function()
		{
			var oOptions = document.forms[0].aFileSelection.options

			if (oOptions.selectedIndex > -1) {
		
				for (var i=oOptions.length-1; i>-1; i--) {
					if (oOptions[i].selected) {
						
						var oContainer = $('file_attach')
						
						for (var c=0; c<oContainer.childNodes.length; c++) {
							if (oContainer.childNodes[c].value == oOptions[i].text) {
								oContainer.removeChild(oContainer.childNodes[c])
								break
							}
						}
		
						oOptions[i] = null
					}
				}
			}

			$('submitButton').disabled = !(oOptions.length > 0)
		},

		attachFile: function(oInput) {
			if (!this.fileExists(oInput.value)) {
				if (this.hideInput()) {
					var oNewInput = this.addFileInput();
					oNewInput.focus()
				}
			}
		},

		validate: function() {
			if (document.forms[0].aFileSelection.options.length == 0) {
				pxp_alert(getTranslation('validFilename'))
				return false
			}
			return true
		},

		dispose: function() {
			var oContainer = $('file_attach')
			if (oContainer) {
				for (var i=0, l=oContainer.childNodes.length; i<l; i++) {
					oContainer.childNodes[i].onchange = null
				}
			}
		}
	}
)