px.Class.define('px.html.Form')

Object.extend(
	px.Statics,
	{
		aIgnoreTypes: ['file', 'submit', 'image', 'reset', 'button'],

		serialize: function(oForm)
		{
			var cArray = px.lang.Array
			var aResult = []
			for (var i=0, l=oForm.elements.length; i<l; i++)
			{
				var oElement = oForm.elements[i]
				var sName = oElement.name
				if (sName && oElement.type)
				{
					if (cArray.contains(this.aIgnoreTypes, oElement.type)  ) {
						continue
					}
					switch (oElement.type) {
						case 'checkbox':
						case 'radio':
							if (oElement.checked) {
								aResult.push(sName + '=' + encodeURIComponent(oElement.value))
							}
							break
						case 'select-multiple':
							for (var i2=0, l2=oElement.options.length; i2<l2; i2++) {
								if (oElement.options[i2].selected) {
									aResult.push(sName + '=' + encodeURIComponent(oElement.options[i2].value))
								}
							}
							break
						default:
							aResult.push(sName + '=' + encodeURIComponent(oElement.value))
							break	
					}
				}
			}
			return aResult.join('&')
		},
		
	  disable: function(oForm) {
	  	for (var i=0, l=oForm.elements.length; i<l; i++) {
	  		var oElement = oForm.elements[i]
	  		oElement.blur()
	  		oElement.disabled = true
	  	}
	  },
	
	  enable: function(oForm) {
	  	for (var i=0, l=oForm.elements.length; i<l; i++) {
	  		oForm.elements[i].disabled = null
	  	}
	  },
	  
	  activate: function(oElement) {
	    try {
	      oElement.focus()
				oElement.select()
	    } catch (e) {}
	  }
	}
)