var iDragOffset = 0
var oActiveItem

function $(sId) {
	return document.getElementById(sId)
}

function pxInit()
{
	pxp.init($('main')) // document.body

;;;	document.title = new Date().getTime() - iStart

	//alert(pxp.iPhpRuntime)
//	pxp.init($('cont'))
}

function pxUnload()
{
	delete oActiveItem

	pxp.oSelectedControl = null

	px.ui.ContextMenu.dispose()

	var aActions = px.action
	for (var a in aActions) {
		if (aActions[a].dispose) {
			aActions[a].dispose()
		}
	}

	var oOverlay = $('overlay')
	if (oOverlay) oOverlay.onclick = null
	if (pxp.bIe) {
		for (var i=0; i<document.images.length; i++) {
			if (document.images[i].style.filter) {
				document.images[i].style.filter = pxConst.EMPTY
			}
		}
		if (oOverlay && oOverlay.style.filter) {
			oOverlay.style.filter = pxConst.EMPTY
		}
	}

	pxp.dispose()

// pxp.checkSubTree(document.body)
//	pxp.checkSubTree($('cont'))

	delete pxp
	delete px	
}


px.Event.addListener(window, 'load', pxInit)
px.Event.addListener(window, 'unload', pxUnload)
px.Event.addListener(window, 'unload', px.Event.unloadCache);