px.Class.define('px.io.RequestParameters',
{
	extend: px.core.Object,
	construct: function()
	{
		this.sShare
		this.sAction = '_openJson'
		this.sPath = '/'
		this.aNames = []
		this.aTypes = []
		this.bFull
		this.sOrderBy = 'sName'
		this.sOrderDirection = 'asc'
		this.sSearchQuery
		this.bOnlyDirectories
		this.bFillOptions
		this.bOsPermissions
		this.bFilesize
		this.bHierarchical
		this.bRecursive
		this.bRecursiveFlat
		this.iOffset = 0
		this.bFile
	}
})

Object.extend(
	px.Proto,
	{
		set: function(oParameters) {
			if (oParameters) {
				for (var o in oParameters) {
					this[o] = oParameters[o]
				}
			}
		},

		sync: function(oParameters) {
			this.sPath = oParameters.sPath
			this.sSearchQuery = oParameters.sSearchQuery
			this.sOrderBy = oParameters.sOrderBy
			this.sOrderDirection = oParameters.sOrderDirection
		},
		
		getUrl: function()
		{
			var aParams = []

			for (var p in this) {
				if (p.indexOf('_') == 0 || p == 'classname') {
					continue
				}

				switch (typeof this[p]) {
					case 'object':
						if (this[p] && this[p].length) {
							var aValues = []
							for (var i=0; i<this[p].length; i++) {
								aValues.push(encodeURIComponent(this[p][i]))
							}
							aParams.push(p + '=' + aValues.join('|'))
						}
						break
					default:
						if (this[p] instanceof Function) {
							continue
						}
						if (this[p] != null && this[p] != undefined) {
							aParams.push(p + '=' + encodeURIComponent(this[p]))
						}
						break
				}
			}

			return aParams.join('&')
		},

		getPath: function(bShare)
		{
			var sPath = ''
			if (bShare != false) {
				sPath += this.sShare + ':'
			}
			sPath =  px.util.buildPath(sPath, this.sPath)
			if (this.aNames.length > 0) {
				sPath = px.util.buildPath(sPath, this.aNames[0])
			}
			return sPath
		}
	}
)