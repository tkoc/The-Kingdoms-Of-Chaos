px.Class.define('px.lang.Function')

Object.extend(
	px.Statics,
	{
    bind: function(oFunction, oObject, varargs)
    {
			if (arguments.length > 2) {
				var args = Array.prototype.slice.call(arguments, 2)
				return function() {
					return oFunction.apply(oObject, args.concat(Array.prototype.slice.call(arguments, 0)))
				}
			} else {
				return function() {
					return oFunction.apply(oObject, arguments)
				}
			}
		},

		bindEvent: function(oFunction, oObject) {
			return function(event) {
				return oFunction.call(oObject, event||window.event)
			}
		},
		
		cancelEvent: function(oEvent) {
			var oEvent = oEvent || window.event
			if (oEvent.preventDefault) {
				oEvent.preventDefault()
				oEvent.stopPropagation()
			} else {
				oEvent.returnValue = false
				oEvent.cancelBubble = true
			}
			return false
		},
		
		returnFalse: function() {
			return false
		}
	}
)