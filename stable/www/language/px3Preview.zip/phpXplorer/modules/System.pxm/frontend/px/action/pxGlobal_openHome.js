px.Class.define('px.action.pxGlobal_openHome',
{
	extend: px.Action,

	construct: function(sId, oParent, oParentNode, oParameters)
	{
		this.base(arguments, sId, oParent, oParentNode)

		px.html.Element.addClassName(this.oDiv, 'pxHomepage')
		
		var oBorder = this.addBorder()

		var sName = pxp.oData.oProfile.sFullName
		if (!sName) {
			sName = pxp.oData['sUser']
		} else {
			sName = pxp.translateTitle(sName)
		}

		var sImageUrl = pxp.oData.sLogoUrl
		if (sImageUrl != '') {
			var oImage = new Image()
			oImage.src = sImageUrl
			oImage.id = 'logo'
			oBorder.appendChild(oImage)
		}

		oBorder.appendChild(document.createTextNode(oTranslation['welcome'] + ' ' + sName + ','))

		oBorder.appendChild(document.createElement('br'))

		oBorder.appendChild(document.createTextNode(oTranslation['home.introduction']))

		if (pxp.sUser != 'everyone')
		{
			this._oToolbar = new px.ui.toolbar.Toolbar(this, oBorder)

			this._oToolbar.addButton(
			{
					sId: 'editProfile',
					sLabel: oTranslation['editProfile'],
					oOnClick: px.lang.Function.bind(px.action.pxGlobal_openHome._editProfile, this)
				}
			)

			this._oToolbar.addButton(
				{
					sId: 'changePassword',
					sLabel: oTranslation['changePassword'],
					oOnClick: px.lang.Function.bind(px.action.pxGlobal_openHome._editPassword, this)
				}
			)
		}

		oBorder.appendChild(document.createTextNode(oTranslation['home.shares']))
		
		this._oToolbarShares = new px.ui.toolbar.Toolbar(this, oBorder, 'SharesList')
		
		for (var sBookmark in pxp.oData.aBookmarks) {
			this._oToolbarShares.addButton(
				{
					sId: sBookmark,
					sLabel: oTranslation['share.' + sBookmark] || pxp.oData.aBookmarks[sBookmark] || sBookmark,
					oOnClick: px.lang.Function.bind(pxp.oShareview.showAction, pxp.oShareview, sBookmark)
				}
			)
		}

	},

	destruct: function() {
		this._disposeObjects('_oToolbar', '_oToolbarShares')
	}
})

Object.extend(
	px.Statics,
	{
		_editProfile: function()
		{
			var sPath = 'profiles/' + pxp.oData.sUser + '.pxProfile'
			var oView = pxp.oShareview.oSelected.oActionviewFiles

			oView.addAction(
				'px:editProfile',
				sPath,
				px.action.pxGlobal___openEditorview,
				true,
				'types/pxProfile',
				{
					sShare: 'phpXplorer',
					sPath: sPath,
		  		sType: 'pxProfile'
				}
			)
			oView.showAction('px:editProfile')
			return false
		},
		
		_editPassword: function()
		{
			var sPath = pxp.oData.sUser
			var oView = pxp.oShareview.oSelected.oActionviewFiles

			oView.addAction(
				'px:editPassword',
				sPath,
				px.action.pxGlobal___openEditorview,
				true,
				'types/pxVfsAuthenticationUser',
				{
					sShare: 'Authentication',
					sPath: sPath,
		  		sType: 'pxVfsAuthenticationUser'
				}
			)
			oView.showAction('px:editPassword')
			return false
		}
	}
)
