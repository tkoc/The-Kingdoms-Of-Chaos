px.Class.define('px.action.pxDirectories__editShare')

Object.extend(
	px.Statics,
	{
		run: function()
		{
			var oListview = pxp.getListview()
			var sPath = oListview.oParameters.sPath
			var sBasename = px.util.basename(sPath)
	
			if (sBasename != '.phpXplorer' && sBasename.indexOf('.pxShare') == -1) {
				
				px.action.pxDirectory__editCreate.run('pxData', '.phpXplorer', false, false)
	
				oListview.oParameters.sPath = px.util.buildPath(
					sPath,
					'.phpXplorer'
				)
				oListview.update()
			}
			
			px.action.pxGlobal_openCreate.run('pxUser')

			return false
		}
	}
)