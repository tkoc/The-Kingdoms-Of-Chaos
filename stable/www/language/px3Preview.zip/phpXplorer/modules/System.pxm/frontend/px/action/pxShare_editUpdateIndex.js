px.Class.define('px.action.pxShare_editUpdateIndex')

Object.extend(
	px.Statics,
	{
		run: function(oView)
		{
			var aItems = []
			for (var sSelected in oView.oSelected) {
				var oItem = oView.oSelected[sSelected]
				aItems.push(oItem.sFilename.replace('/shares/', ''))
			}
	
			if (confirm('Do you really want to index \'' + aItems.join(',') + '\'?')) {
				px.action.pxMetaFiles_openView.run(oView, 'editUpdateIndex')
			}
		}
	}
)