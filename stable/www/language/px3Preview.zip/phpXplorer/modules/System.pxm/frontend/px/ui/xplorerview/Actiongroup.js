px.Class.define('px.ui.xplorerview.Actiongroup',
{
	extend: px.ui.xplorerview.Item,

	construct: function(sId, oParent, oParentNode)
	{
		this.bGroupsRendered = this.bGroupsExpanded = false

		this.base(arguments,
			sId,
			oParent,
			oParentNode,
			'pxActiongroup.png',
			oTranslation[sId.split('.')[1]]
		)
	}
})

Object.extend(
	px.Proto,
	{
		hasChildren: function() {
			return true
		},

		expand: function()
		{
			var cElement = px.html.Element

			if (this.bRendered) {
				this.bExpanded = !this.bExpanded
				this.oDivChildren.style.display = this.bExpanded ? '' : 'none'
			} else {
				var aPart = this.sId.split('.')
				var sType = aPart[0]
				var sSelectedBaseAction = aPart[1]
				var bFirst = false
				for (var a=0, m=pxp.oTypes[sType].aActions.length; a<m; a++) {
					var sAction = pxp.oTypes[sType].aActions[a]
					var sBaseAction = pxp.oActions[sAction][2]
					if (sBaseAction != sSelectedBaseAction) {
						continue
					}
					var sId = sType + '.' + sBaseAction + '.' + sAction
					this.oParent.oItems[sId] = new px.ui.xplorerview.Action(sId, this.oParent, this.oDivChildren)
					if (!bFirst) {
						cElement.addClassName(this.oParent.oItems[sId].oDiv, 'firstNode')
						bFirst = true
					}
				}
				this.bRendered = this.bExpanded = true
			}
			this.oExpandImage1.src = pxConst.sGraphicUrl + (this.bExpanded ? '/collapse.png' : '/expand.png')
		}
	}
)