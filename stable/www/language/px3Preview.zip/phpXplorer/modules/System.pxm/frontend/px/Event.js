px.Class.define('px.Event')

Object.extend(
	px.Statics,
	{
		element	: function(oEvent) {
			return oEvent.target || oEvent.srcElement
		},

		_aListeners: [],

		_addAndCache: function(oElement, sName, oListener, bCapture) {
			if (oElement.attachEvent) {
				oElement.attachEvent('on' + sName, oListener)
			} else {
				oElement.addEventListener(sName, oListener, bCapture)
			}
			px.Event._aListeners.push([oElement, sName, oListener, bCapture])
		},

		unloadCache: function() {
			var cEvent = px.Event
			for (var i=0, l=cEvent._aListeners.length; i<l; i++) {
				cEvent.removeListener.apply(this, cEvent._aListeners[i])
				cEvent._aListeners[i][0] = null
			}
			cEvent._aListeners = null
		},

		addListener: function(oElement, sName, oListener, bCapture) {
			//if (sName == 'keypress' && (Prototype.Browser.WebKit || oElement.attachEvent)) {
			//	sName = 'keydown'
			//}
			px.Event._addAndCache(oElement, sName, oListener, bCapture || false)
		},

		removeListener: function(oElement, sName, oListener, bCapture) {
			//if (sName == 'keypress' && (Prototype.Browser.WebKit || oElement.attachEvent)) {
			//	sName = 'keydown'
			//}
			if (oElement.removeEventListener) {
				oElement.removeEventListener(sName, oListener, bCapture || false)
			} else if (oElement.detachEvent) {
				try {
					oElement.detachEvent('on' + sName, oListener)
				} catch (e) {}
			}
		},
		
		pointerX: function(oEvent) {
			return oEvent.pageX || (oEvent.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft))
		},
		
		pointerY: function(oEvent) {
			return oEvent.pageY || (oEvent.clientY + (document.documentElement.scrollTop || document.body.scrollTop))
		}
	}
)