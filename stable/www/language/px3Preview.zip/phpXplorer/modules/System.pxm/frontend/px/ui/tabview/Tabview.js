px.Class.define('px.ui.tabview.Tabview',
{
	extend: px.core.Object,

	construct: function(oParent, oParentNode, oInsertBefore) {
		this.oParent = oParent
		this.oParentNode = oParentNode	
		this.oInsertBefore = oInsertBefore
		//this.iTabCount = 0
		this.oSelected
		this.onTabClick
		this.oTabs = {}
	},

	destruct: function() {
		this._disposeFields('oParent', 'oParentNode', 'oInsertBefore', 'oSelected', 'onTabClick')
		this._disposeContents('oTabs')
	}
})

Object.extend(
	px.Proto,
	{
		addTab: function(sId, sTitle, bSelected) {
			this.oTabs[sId] = new px.ui.tabview.Button(this, sId, sTitle)
			//this.iTabCount++
			if (bSelected) {
				this.setSelected(sId, true)
			}
		},

		removeTab: function(sId) {
			var oDiv = this.oTabs[sId].oDiv
			this.oTabs[sId].dispose()
			this.oParentNode.removeChild(oDiv)
			delete this.oTabs[sId]
			//this.iTabCount--
		},

		setSelected: function(sId, bInitializing)
		{
			if (!this.oTabs[sId]) {
				return false
			}

			if (this.oSelected == this.oTabs[sId]) {
				return false
			}

			for (var t in this.oTabs) {
				this.oTabs[t].oDiv.className = 'pxTab'
			}
			
			this.oTabs[sId].oDiv.className = 'pxTab pxSelectedTab'

			this.oSelected = this.oTabs[sId]
			if (this.onTabClick && !bInitializing) {
				this.onTabClick(sId)
			}
		}
	}
)