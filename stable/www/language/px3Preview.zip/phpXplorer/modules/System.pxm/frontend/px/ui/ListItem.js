px.Class.define('px.ui.ListItem',
{
	extend: px.core.Object,
	type: 'abstract'
})

Object.extend(
	px.Proto,
	{
		getFilename: function() {
			return px.util.basename(this.sFilename)
		},

		getDirname: function() {
			return px.util.dirname(this.sFilename)
		},

		getPath: function() {
			if (this.oParent.oParameters.sSearchQuery || this.oParent.oParameters.bRecursiveFlat) {
				return this.oParent.oParameters.getPath()
			} else {
				return px.util.buildPath(
					this.oParent.oParameters.sShare + ':',
					this.getDirname()
				)
			}
		},

		getType: function() {
			if (this.sFilename == '/') return 'pxDirectory'
			return this.oParent.oResults[this.getPath()][this.iIndex].sType
		},

		getExtension: function() {
			return this.oParent.oResults[this.getPath()][this.iIndex].sExtension
		},

		getShare: function() {
			return this.oParent.oParameters.sShare
		},

		move: function(oEvent) {
			var oDragable = $('dragable')
			if (!oDragable) {
				oDragable = document.createElement('ul')
				oDragable.id = 'dragable'
				document.body.appendChild(oDragable)
				for (var sSelected in this.oParent.oSelected) {
					var oRow = this.oParent.oSelected[sSelected]
					var oItem = document.createElement('li')
					oDragable.appendChild(oItem)
					oItem.appendChild(document.createTextNode(oRow.getFilename()))
				}
			}
			oDragable.style.top = oEvent.clientY + 10 + 'px'
			oDragable.style.left = oEvent.clientX + 10 + 'px'
			oDragable = null
		},
	
		mouseDown: function(oEvent)
		{
			oEvent.cancelBubble = true
			if (pxp.bHold) {
				return false
			}

			this.selectItem(
				oEvent,
				px.Event.element(oEvent).nodeName.toLowerCase() == 'a' &&
				this.oParent.oSelected[this.sFilename] && !oEvent.ctrlKey
			)
	
			this.oParent.oActiveItem = this
			pxp.setActiveControl(this.oParent)
	
			pxp.startDrag('item')
			document.onmousemove = px.lang.Function.bindEvent(this.move, this)
		},
	
		itemClick: function(oEvent)
		{
			oEvent.cancelBubble = true

			var oParent = this.oParent
			
			if (oParent.bChecklist) {
				return false
			}

			var sPath = this.getPath()
			var sType = oParent.oResults[sPath][this.iIndex].sType

			oParent.showContextMenu(
				this,
				oEvent,
				sType,
				oParent.oSettings[sPath].aAllowedActions[sType]
			)
		},

		itemDblClick: function(oEvent) {
			px.ui.ContextMenu.hide()
			this.fileClick(oEvent)
		},

		fileClick: function(oEvent) {
			oEvent.cancelBubble = true
			if (pxp.bHold) {
				return false
			}
			var oParent = this.oParent
			if (!oEvent.ctrlKey && (!oParent.bChecklist || this.bDirectory)) {
				pxp.bHold = true
				if (this.bDirectory) {
					oParent.oSelected = {}
					oParent.oParameters.sPath = this.sFilename
					oParent.oParameters.sSearchQuery = null
					oParent.update({_bReload: false})
					if (oParent.onDirChange) oParent.onDirChange()
				} else {
					this.selectItem(oEvent)
					oParent.callAction(pxp.oTypes[this.getType()].aDefaultActions[0], oEvent)
				}
				window.setTimeout('pxp.bHold=false', 250)
			}
			return false
		}
	}
)