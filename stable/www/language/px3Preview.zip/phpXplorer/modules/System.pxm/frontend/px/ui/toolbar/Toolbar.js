px.Class.define('px.ui.toolbar.Toolbar',
{
	extend: px.core.Object,

	construct: function(oParent, oParentNode, sId)
	{
		this.oParent = oParent
		this.oParentNode = oParentNode
		
		this.oButtons = {}

		this.iIconSize = 16
		
		this.oDiv = document.createElement('div')
		this.oDiv.className = 'pxToolbar'
		if (sId) {
			this.oDiv.id = sId
		}

		if (this.oParent.bToolbarFirst) {
			this.oParentNode.insertBefore(this.oDiv, this.oParentNode.firstChild)
		} else {
			this.oParentNode.appendChild(this.oDiv)
		}
	},

	destruct: function() {
		this._disposeFields('oParent', 'oParentNode', 'oDiv')
		this._disposeContents('oButtons')
	}
})

Object.extend(
	px.Proto,
	{
		addButton: function(oOptions) {
			this.oButtons[oOptions.sId] = new px.ui.toolbar.Button(this, oOptions)
			if (oOptions.bHidden) {
				this.hideButton(oOptions.sId)
			}
		},

		showButton: function(sId) {
			if (this.oButtons[sId]) {
				this.oButtons[sId].oA.style.display = 'block'
			}
		},

		hideButton: function(sId) {
			if (this.oButtons[sId]) {
				this.oButtons[sId].oA.style.display = 'none'
			}
		},

		removeButton: function(sId) {
			var oA = this.oButtons[sId].oA
			this.oButtons[sId].dispose()
			this.oDiv.removeChild(oA)
			delete this.oButtons[sId]
		},

		enableButton: function(sId) {
			var oButton = this.oButtons[sId]
			px.html.Element.removeClassName(oButton.oA, 'pxTbDisabled')
			if (oButton.oOnClick && oButton.oOnClick instanceof Function) {
				oButton.oA.onclick = oButton.oOnClick
				oButton.changeImage(pxConst.sGraphicUrl + '/' + oButton.sIcon)
			}
		},

		disableButton: function(sId) {
			var oButton = this.oButtons[sId]
			px.html.Element.addClassName(oButton.oA, 'pxTbDisabled')
			oButton.oA.onclick = px.lang.Function.cancelEvent
			var sDir = px.util.dirname(oButton.sIcon)
			var sName = px.util.basename(oButton.sIcon)
			var sPath = px.util.buildPath(sDir, 'disabled_' + sName)
			oButton.changeImage(pxConst.sGraphicUrl + '/' + sPath)
		},

		addDivider: function() {
			var oDivider = document.createElement('div')
			oDivider.className = 'pxTbDivider'
			this.oDiv.appendChild(oDivider)
		}
	}
)