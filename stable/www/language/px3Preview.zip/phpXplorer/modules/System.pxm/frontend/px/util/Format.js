px.Class.define('px.util.Format')

Object.extend(
	px.Statics,
	{
		number: function(iNumber)
		{
			var sNumber = String(iNumber)
			var oRegExp = new RegExp('(-?[0-9]+)([0-9]{3})')
	
			while(oRegExp.test(sNumber)) {
				sNumber = sNumber.replace(oRegExp, '$1.$2')
			}
			return sNumber
		},

		datetime: function(iPhpTime) {
			var oDate = new Date();
			oDate.setTime(iPhpTime * 1000)
			var sDate = oDate.getFullYear() + '-'
			var addZero = px.util.addLeadingZero
			sDate += addZero(oDate.getMonth() + 1) + '-'
			sDate += addZero(oDate.getDate()) + ' '
			sDate += addZero(oDate.getHours()) + ':'
			sDate += addZero(oDate.getMinutes()) + ':'
			sDate += addZero(oDate.getSeconds())
			return sDate
		}
	}
)