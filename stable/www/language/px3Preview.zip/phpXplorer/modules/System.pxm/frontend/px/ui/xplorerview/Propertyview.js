px.Class.define('px.ui.xplorerview.Propertyview',
{
	extend: px.core.Object,

	construct: function(oParent) {
		this.oParent = oParent
		this.sCurrentId
	},
	
	destruct: function() {
		this.oEventLabel.onclick = null
		this.oEvent.onchange = null
		this._disposeFields(
			'oParent', 'oParentNode', 'oEventLabel', 'oEvent' // 'oInheritedEventLabel', 'oInheritedEvent', 'oParameterLabel'
		)
	}
})

Object.extend(
	px.Statics,
	{
		_eventLabelClick: function(oEvent) {
			pxp.oSelectedControl = this
			var oCm = px.ui.ContextMenu
			oCm.clear()
			oCm.addItem('action', 'Aktion ausl�sen', pxConst.sGraphicUrl + '/types/pxAction_pxAction.php.png', false)
			oCm.addItem('email', 'E-Mail senden', pxConst.sGraphicUrl + '/actions/pxGlobal_sendMail.png', false)
			oCm.show(oEvent)
		},

		_eventCodeChange: function() {
			var oView = this.oParent.oXplorerview
			var oActive = oView.oActiveItem
			if (oActive) {
				var sId = oActive.sId	
				if (this.oEvent.value != '') {
					if (!oView.oObject.aEvents[sId]) {
						if (oActive.oA.nextSibling) {
							px.html.Element.appendImage(oActive.oDiv, pxConst.sGraphicUrl + '/bulletGo.png', oActive.oA.nextSibling)
						} else {
							px.html.Element.appendImage(oActive.oDiv, pxConst.sGraphicUrl + '/bulletGo.png')
						}
					}
					oView.oObject.aEvents[sId] = this.oEvent.value
				} else {
					if (oView.oObject.aEvents[sId]) {
						oActive.oDiv.removeChild(oActive.oA.nextSibling)
					}
					delete oView.oObject.aEvents[sId]
				}
			}
		}
	}
)

Object.extend(
	px.Proto,
	{
		init: function(oParentNode)
		{
			this.oParentNode = oParentNode

			px.html.Element.addClassName(this.oParentNode, 'pxXplorerview')

			/*
			var oLabel = document.createElement('label')
			this.oParentNode.appendChild(oLabel)
			oLabel.appendChild(document.createTextNode('Geerbte Ereignisse'))
		
			this.oInheritedEvent = document.createElement('textarea')
			this.oInheritedEvent.cols = 40
			this.oInheritedEvent.rows = 4
			this.oParentNode.appendChild(this.oInheritedEvent)
			this.oInheritedEvent.disabled = true
			*/

			this.oEventLabel = document.createElement('label')
			var oLabel = this.oEventLabel
			this.oParentNode.appendChild(oLabel)
			oLabel.appendChild(document.createTextNode(oTranslation['aEvents']))
			oLabel.onclick = px.lang.Function.bindEvent(px.ui.xplorerview.Propertyview._eventLabelClick, this)
		
			this.oEvent = document.createElement('textarea')
			this.oEvent.cols = 40
			this.oEvent.rows = 9
			this.oParentNode.appendChild(this.oEvent)
			this.oEvent.onchange = px.lang.Function.bind(px.ui.xplorerview.Propertyview._eventCodeChange, this)
		
			/*
			this.oParameterLabel = document.createElement('label')
			this.oParentNode.appendChild(this.oParameterLabel)
			this.oParameterLabel.appendChild(document.createTextNode(oTranslation['aParameters']))
			*/
		},
		
		callAction: function(sAction) {
			switch (sAction) {
				case 'email':
					this.oEvent.value = '<action id="sendMail">' + "\n" +
						'  <param id="from"></param>' + "\n" +
						'  <param id="to"></param>' + "\n" +
						'  <param id="cc"></param>' + "\n" +
						'  <param id="bcc"></param>' + "\n" +
						'  <param id="subject"></param>' + "\n" +
						'  <param id="text"></param>' + "\n" +
						'</action>'
					break
				case 'action':
					this.oEvent.value = '<action id="">' + "\n" +
						'  <param id=""></param>' + "\n" +
						'</action>'
					break
			}
		},

		resize: function(bFinished)
		{
			this.oEvent.style.width = this.oParentNode.offsetWidth - 30 + 'px'
			this.oEvent.style.height = this.oParentNode.offsetHeight - 30 + 'px'
		}	}
)