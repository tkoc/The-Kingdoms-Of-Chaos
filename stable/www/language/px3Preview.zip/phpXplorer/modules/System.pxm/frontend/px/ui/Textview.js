px.Class.define('px.ui.Textview',
{
	extend: px.io.RemoteView,
	
	construct: function(oParent, oParentNode)
	{
		this.base(arguments, oParent, oParentNode)

		this.oParameters.sAction = 'edit'

		this.oForm = document.createElement('form')
		this.oForm.className = 'pxTextview'
		this.oForm.method = 'post'
		this.oForm.action = pxp.sUrl
		oParentNode.appendChild(this.oForm)

		this.oTextarea = document.createElement('textarea')
		this.oTextarea.name = 'sContent'
		this.oTextarea.className = 'pxTextview'
		this.oTextarea.setAttribute('wrap', 'off')
		this.oTextarea.style.overflow = 'auto'	
		this.oForm.appendChild(this.oTextarea)
		this.oTextarea.onchange = px.lang.Function.bind(this.onTextChange, this)		
	},

	destruct: function() {
		this.oTextarea.onchange = null
		this._disposeFields('oParent', 'oParentNode', 'oForm', 'oTextarea')
	}
})

Object.extend(
	px.Proto,
	{
		onTextChange: function() {
			this.oParent.setChanged(true)
		},
		
		save: function()
		{
			var oResult = this._save({sAction: 'edit'})
		
			if (oResult.bOk) {
				pxp.refreshView(px.util.dirname(this.oParameters.sPath))
				this.oParent.setChanged(false)
			}
			return false
		},

		_update: function() {
			this.oTextarea.value = this.oResults[this.oParameters.getPath()]
			px.html.Form.enable(this.oForm)
			this.oTextarea.focus()
		}
	}
)