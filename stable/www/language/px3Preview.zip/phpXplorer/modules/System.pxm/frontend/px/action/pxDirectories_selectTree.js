px.Class.define('px.action.pxDirectories_selectTree',
{
	extend: px.Action,

	construct: function(sId, oParent, oParentNode, oParametersIn)
	{
		this.base(arguments, sId, oParent, oParentNode)
		
		var sBookmark = this.oShare.sId
		var sTitle = oTranslation['share.' + sBookmark] || pxp.oData.aBookmarks[sBookmark] || sBookmark	

		this.oChild = new px.ui.treeview.Treeview(this, this.oDiv, sTitle)

		var oTree = this.oChild

		oTree.onNodeClick = px.lang.Function.bind(this._onNodeClick, this)
		oTree.oParameters.sShare = this.oShare.sId
		oTree.oParameters.bOnlyDirectories = !this.oShare.bFullTree

		oTree.update()
	}
})

Object.extend(
	px.Proto,
	{
		_onNodeClick: function(oNode) {
			if (oNode.bDirectory) {
				var oActionview = this.oParent.oParent.oActionviewList
				if (oActionview) {
					var oList = oActionview.oSelected.oChild
					oList.oParameters.sPath = oNode.sFilename
					oList.update()
					if (oList.onDirChange) {
						oList.onDirChange()
					}
				}
			}
		}
	}
)