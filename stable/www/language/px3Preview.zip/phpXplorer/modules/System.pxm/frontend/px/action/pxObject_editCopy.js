px.Class.define('px.action.pxObject_editCopy')

Object.extend(
	px.Statics,
	{
		run: function(oView) {
			px.action.pxObject___edit.runSelectionAction(
				'sAction=_editClipboard' +
				'&sDestinationShare={@share}' +
				'&sDestinationPath={@dirname}' +
				'&sMode=copy'
			)
		}
	}
)