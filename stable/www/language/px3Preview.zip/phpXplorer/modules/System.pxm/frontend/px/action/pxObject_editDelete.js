px.Class.define('px.action.pxObject_editDelete')

Object.extend(
	px.Statics,
	{
		run: function(oView) {
			if (confirm(oTranslation['reallyDelete'])) {
				px.action.pxObject___edit.runSelectionAction(
					'sAction=_editDeleteSelection'
				)
			}
		}	
	}
)