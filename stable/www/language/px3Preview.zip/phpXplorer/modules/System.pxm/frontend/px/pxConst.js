var pxConst =
{
	EMPTY : '',
	EMPTY_FUNCTION : function(){},
	DUMMY_LINK: '#',
	
	ALPHA_IMAGE_START: 'progid:DXImageTransform.Microsoft.AlphaImageLoader(src="',
	ALPHA_IMAGE_STOP: '")',
	ALPHA_IMAGE_SCALE_STOP: '", sizingMethod="scale")',

	MENU_TABS: 0,
	MENU_BUTTON: 1,
	
	TOOLBAR_HORIZONTAL: 0,
	TOOLBAR_VERTICAL: 1,
	
	TOOLBAR_BUTTON_LINK: 0,
	TOOLBAR_BUTTON_INPUT: 1
}