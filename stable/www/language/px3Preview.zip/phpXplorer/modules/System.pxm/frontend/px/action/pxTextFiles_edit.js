px.Class.define('px.action.pxTextFiles_edit',
{
	extend: px.action.pxObject___edit,

	construct: function(sId, oParent, oParentNode, oParameters)
	{
		//this.oParent = oParent

		this.base(arguments, sId, oParent, oParentNode, oParameters)

		this.oChild = new px.ui.Textview(this, this.oDiv)
		this.oChild.oParameters.sShare = this.oShare.sId
		this.oChild.oParameters.set(oParameters)

		if (!oParameters._bNew) {
			px.html.Form.disable(this.oChild.oForm)
			this.oChild.update({sAction: '_open'})
		} else {
			this.oChild.oTextarea.focus()
		}
	}
})