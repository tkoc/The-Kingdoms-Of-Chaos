px.Class.define('px.action.pxObject___edit',
{
	extend: px.Action,

	construct: function(sId, oParent, oParentNode, oParametersIn)
	{
		this.base(arguments, sId, oParent, oParentNode)

		var cFunction = px.lang.Function

		this.oToolbar.addButton(
			{
				sId: '__docLink',
				sLabel: oTranslation['toolbar.documentation'],
				sIcon: 'helpLight.png',
				oOnClick: cFunction.bind(this.openDocs, this),
				bRight: true
			}
		)
		this.oToolbar.addButton(
			{
				sId: 'save',
				sLabel: oTranslation['toolbar.save'],
				sIcon: 'disk.png',
				oOnClick: cFunction.bind(this.save, this),
				bRight: true
			}
		)
	}
})

Object.extend(
	px.Statics,
	{
		checkSelection: function(oControl) {
			// all source files have to in the same directory
			if (oControl instanceof px.ui.treeview.Treeview) {
				var sActiveDir
				var bAllInSameDir = true
				for (var sSelected in oControl.oSelected) {
					var oSelectedItem = oControl.getNode(sSelected)
					if (sActiveDir && sActiveDir != oSelectedItem.getDirname()) {
						bAllInSameDir = false
						break
					}
					sActiveDir = oSelectedItem.getDirname()
				}
				if (!bAllInSameDir) {
					alert(oTranslation['allInSameDir'])
					return false
				}
			}
			return true
		},

		runSelectionAction: function(sParameters)
		{
			var oControl = pxp.oSelectedControl
			var sShare = pxp.oShareview.oSelected.oShare.sId
		
			if (!px.action.pxObject___edit.checkSelection(oControl)) {
				return false
			}
		
			var oListview = pxp.getListview()
			var bOpened = false
			var aFiles = []
		
			for (var sSelected in oControl.oSelected) {
				if (oControl.oSelected[sSelected].getType() != 'pxVirtualDirectory') {
					if (sSelected == oListview.oParameters.sPath) {
						bOpened = true
					}
					aFiles.push(px.util.basename(sSelected))
					if (!sDirname) {
						var sDirname = px.util.dirname(sSelected)
					}
				}
			}
		
			// Navigate to top if current directory will be removed
			if (bOpened) {
				oListview.oParameters.sPath = '/'
				oListview.update()
			}
		
			sParameters = sParameters.replace(/{@share}/g, encodeURIComponent(sShare))
			sParameters = sParameters.replace(/{@dirname}/g, encodeURIComponent(sDirname))

			var oResult = px.io.Request.post(
				'sShare=' + encodeURIComponent(sShare) +
				'&sPath=' + encodeURIComponent(sDirname) +
				'&aNames=' + encodeURIComponent(aFiles.join('|')) +
				'&' + sParameters
			)

			if (oResult.bOk) {
				pxp.refreshView(sDirname)
			}
		}
	}
)

Object.extend(
	px.Proto,
	{
		openDocs: function() {
			if (this.oChild.oObject.sType) {
				pxp.showDoc('type/' + this.oChild.oObject.sType)
			} else {
				pxp.showDoc('action/' + this.oParent.oSelected.sId)
			}
		}
	}
)