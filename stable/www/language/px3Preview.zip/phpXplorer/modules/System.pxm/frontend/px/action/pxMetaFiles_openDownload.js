px.Class.define('px.action.pxMetaFiles_openDownload')

Object.extend(
	px.Statics,
	{
		run: function(oView)
		{
			if (px.util.getLength(oView.oSelected) == 1) {
				for (var sSelected in oView.oSelected) {
					location.href = this.getUrl(oView, sSelected)
				}
			} else {
				for (var sSelected in oView.oSelected) {
					window.open(
						this.getUrl(oView, sSelected),
						px.util.getRandomId()
					)
				}
			}
		},
	
		getUrl: function(oView, sSelected) {
			return './action.php?sShare=' + oView.oParent.oShare.sId + '&sAction=openDownload&sPath=' +
				encodeURIComponent(oView.oSelected[sSelected].sFilename)
		}
	}
)