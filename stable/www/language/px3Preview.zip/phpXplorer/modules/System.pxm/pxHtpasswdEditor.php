<?php
/* Copyright notice */

// Include passwd class for password encryption
require_once $pxp->sModuleDir . '/System.pxm/includes/PEAR/Passwd.php';

/**
 * Apache style .htpasswd file editor class
 */
class pxHtpasswdEditor
{
	var $aUsers = array();
	var $aPasswords = array();

	var $filename = '';
	var $aDeletedUsers = array();

	function pxHtpasswdEditor($sFilename)
	{
		if (empty($sFilename)) {
			die('Filename is empty!');
		}

		if(!file_exists($sFilename)) {
			die("File '$sFilename' not found!");
		}

		$this->filename = $sFilename;
		
		$aLines = file($sFilename);
		
		foreach ($aLines as $sLine) {
			$values = explode(':', $sLine);
			array_push($this->aUsers, trim($values[0]));
			array_push($this->aPasswords, trim($values[1]));
		}
	}
	
	function addUser($sUsername, $sPassword)
	{
		for ($u = 0; $u < sizeof($this->aUsers); $u++) {
			if ($this->aUsers[$u] == $sUsername) {
				$this->aPasswords[$u] = $this->_getPassword($sPassword);
				return true;
			}
		}
		
		array_push($this->aUsers, $sUsername);
		array_push($this->aPasswords, $this->_getPassword($sPassword));
		return true;
	}
	
	function deleteUser($sUsername)
	{
		$iSelIndex = -1;
				
		for ($u = 0; $u < sizeof($this->aUsers); $u++) {
			if ($this->aUsers[$u] == $sUsername) {
				$iSelIndex = $u;
			}
		}

		if ($iSelIndex > -1) {
			array_push($this->aDeletedUsers, $iSelIndex);
		} else {
			return false;
		}
	}
	
	function _getPassword($sPassword)
	{
		global $pxp;
		
		$pxp->oAuthentication = $pxp->getObject($pxp->aConfig['sAuthentication']);
		
		if (strpos(strToUpper(PHP_OS), 'WIN') === false) {
			return File_Passwd::crypt_des($sPassword, $pxp->oAuthentication->sSalt);
		} else {
			return File_Passwd::crypt_apr_md5($sPassword, $pxp->oAuthentication->sSalt);
		}
	}
	
	function writeFile()
	{
		global $pxp;

		$content = '';

		for ($u = 0; $u < sizeof($this->aUsers); $u++) {
			if (!in_array($u , $this->aDeletedUsers)) {
				$content .= $this->aUsers[$u] . ':' . $this->aPasswords[$u] . "\n";
			}
		}

		$pxp->oVfs->file_put_contents($this->filename, $content);
	}
}

?>