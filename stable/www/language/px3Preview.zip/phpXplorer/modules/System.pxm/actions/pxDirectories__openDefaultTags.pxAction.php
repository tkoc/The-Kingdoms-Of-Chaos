<?php
/* Copyright notice */

class pxDirectories__openDefaultTags extends pxAction
{
	/**
	 *
	 */
	function run()
	{
		global $pxp;

		$aTags = $pxp->oObject->_getOptions('aTags');
		$aTags = array_merge($aTags, $pxp->oObject->aDefaultTags);
		$this->sendJson($aTags);
	}
}

?>