<?php
/* Copyright notice */

class pxMetaFiles_openView extends pxAction
{
	/**
	 * 
	 */
	function run()
	{
		global $pxp;

   	if ($pxp->oShare->iRestrictWebserverAccess > 1)
   	{
			foreach ($pxp->aTypes[$pxp->oObject->sType]->aExtensions as $iIndex => $sExtension) {
				if ($sExtension == $pxp->oObject->sExtension) {
					$this->sMimeType = $pxp->aTypes[$pxp->oObject->sType]->aMimeTypes[$iIndex];
					break;
				}
			}
   		if ($this->sMimeType == 'application/x-httpd-php') {
				$pxp->oObject->execute();
   		} else {
   			$this->sendHeaders();
				echo $pxp->oObject->getContents();
   		}
   	}
   	else
   	{
			header('Location:' . pxUtil::buildPath($pxp->oShare->sUrl, $pxp->encodeURIParts($pxp->sRelPathIn)));
   	}
	}
}

?>
