<?php
/* Copyright notice */

class pxObject__editExists extends pxAction {
	
	function run() {
		global $pxp;

		$this->sendJson(
			array(
				'bOk' => true,
				'bDirectory' => $pxp->oObject->bDirectory
			)
		);
	}
}

?>