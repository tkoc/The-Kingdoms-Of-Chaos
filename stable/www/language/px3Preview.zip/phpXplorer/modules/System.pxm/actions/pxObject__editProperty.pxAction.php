<?php
/* Copyright notice */

class pxObject__editProperty extends pxAction
{
	/**
	 * @access protected
	 * @var string
	 */
	var $sProperty = array();

	/**
	 * Array of object properties
	 * 
	 * @access protected
	 * @var array Array of pxProperty objects
	 */
	var $aProperties = array();

	/**
	 * 
	 */
	function pxObject__editProperty()
	{
		global $pxp;
		
		$pxp->loadType('pxProperty');

		$this->sProperty = $pxp->getRequestVar('sProperty');
		$this->aProperties = $pxp->aTypes[$pxp->oObject->sType]->getAllProperties();
		parent::pxAction();
	}

	function setProperty($oProperty, &$aErrors)
	{
		global $pxp;

		if ($oProperty->sMode == 'edit') {

			$mValue = $pxp->getRequestVar('px_' . $oProperty->sId);

			// Validation

			if (isset($oProperty->sValidation)) {

				require_once $pxp->sModuleDir . '/System.pxm/includes/PEAR/Validate.php';

				switch ($oProperty->sValidation) {
				case 'number':
					if (!Validate::number($mValue, $oProperty->aValidationParameters)) {
						$aErrors[$oProperty->sId] = 'invalidNumber';
					}
					break;
				case 'email':
					if (!empty($mValue)) {
						if (!Validate::email($mValue, isset($oProperty->aValidationParameters['check_domain']))) {
							$aErrors[$oProperty->sId] = 'invalidEmail';
						}
					} else {
						if (isset($oProperty->aValidationParameters['required'])) {
							$aErrors[$oProperty->sId] = 'invalidEmail';
						}
					}
					break;
				case 'string':
					if (!Validate::string($mValue, $oProperty->aValidationParameters)) {
						$aErrors[$oProperty->sId] = 'invalidString';
					}
					break;
				case 'uri':
					if (!empty($mValue)) {
						if (!Validate::uri($mValue, $oProperty->aValidationParameters)) {
							$aErrors[$oProperty->sId] = 'invalidUri';
						}
					} else {
						if (isset($oProperty->aValidationParameters['required'])) {
							$aErrors[$oProperty->sId] = 'invalidUri';
						}
					}
					break;
				case 'date':
					if (!Validate::date($mValue, $oProperty->aValidationParameters)) {
						$aErrors[$oProperty->sId] = 'invalidDate';
					}
					break;
				case 'filename':
					if (!empty($mValue)) {
						if (!pxUtil::checkFilename($mValue)) {
							$aErrors[$oProperty->sId] = 'invalidFilename';
						}
					} else {
						if (isset($oProperty->aValidationParameters['required'])) {
							$aErrors[$oProperty->sId] = 'invalidFilename';
						}
					}
					break;
				case 'equalTo':
					$mValue2 = $pxp->getRequestVar('px_' . $oProperty->aValidationParameters['compareTo']);
					if ($mValue != $mValue2) {
						$aErrors[$oProperty->sId] = 'passwordsNotEqual';
					}
				break;
				default:
					$pxp->raiseError('unknownValidationMethod', __FILE__, __LINE__, array($oProperty->sValidation));
					break;
				}
			}
			switch ($this->aProperties[$oProperty->sId]->sDataType) {
			case 'array':
				if (is_array($mValue)) {
					$pxp->oObject->setValue($oProperty->sId, $mValue);
				} else {
					if (trim($mValue) != '') {
						$mValue = str_replace(chr(13) . chr(10), chr(13), $mValue);
						$mValue = str_replace(chr(10), chr(13), $mValue);
						$aValuesIn = explode(chr(13), $mValue);
						$aValues = array();
						foreach ($aValuesIn as $sValue) {
							if (!empty($sValue)) {
								$aValues[] = $sValue;
							}
						}
						$pxp->oObject->setValue($oProperty->sId, $aValues);
					} else {
						$pxp->oObject->setValue($oProperty->sId, null);
					}
				}
			break;
			case 'integer':
			case 'int':
				$pxp->oObject->setValue($oProperty->sId, (int)$mValue);
			break;
			case 'boolean':
			case 'bool':
			case 'checkbox':
				$pxp->oObject->setValue($oProperty->sId, $mValue == 'true');
			break;
			default: // string
				$pxp->oObject->setValue($oProperty->sId, $mValue);
			break;
			}
		}
	}

	/**
	 * Main method to start execution of action
	 */
	function run()
	{
		global $pxp;

		if ($pxp->_POST)
		{
			$aErrors = array();

			$this->setProperty(
				$this->aProperties[$this->sProperty],
				$aErrors
			);
			
			$this->storeObject($aErrors);
		}
	}
}

?>