<?php
/* Copyright notice */

class pxGlobal_openIndexData extends pxAction
{
	/**
	 * @var array
	 * @access private
	 */
	var $_aBookmarks = array();

	/**
	 * @var string
	 * @access private
	 */
	var $_sDefaultBookmark;

	var $sMimeType = 'text/javascript';

	/**
	 * 
	 */
	function run()
	{
		global $pxp;

		$bFirst = true;
		
		#$sClient = $pxp->getRequestVar('sClient');

		foreach ($pxp->aBookmarks as $sBookmark)
		{
			if (strpos($sBookmark, 'px') === 0 && strlen($sBookmark) == 34)
			{
				// Bookmark
				$sContent = $pxp->oVfs->file_get_contents(
					$pxp->sDir . '/bookmarks/' . $sBookmark
				);

				$sShare = substr($sContent, 0, strpos($sContent, '|'));				
				$pxp->loadShare($sShare);
				$sRelDir = substr($sContent, strpos($sContent, '|') + 1);

				if (isset($pxp->aShares[$sShare])) {

					$oUserShare =& $pxp->aShares[$sShare]->oVfs->get_object(
						pxUtil::buildPath(
							pxUtil::buildPath(
								$pxp->aShares[$sShare]->sRealBaseDir,
								$sRelDir
							),
							'.phpXplorer/' . $pxp->sUser . '.pxUser'
						),
						false,
						false
					);


					if (!empty($oUserShare->sTitle)) {
						$this->_aBookmarks[$sBookmark] =
							$sShare . ': ' . $oUserShare->sTitle;
					} else {
						$this->_aBookmarks[$sBookmark] = $sShare . ': ' . basename($sRelDir);
					}

					if ($bFirst) {
						$this->_sDefaultBookmark = $sBookmark;
						$bFirst = false;
					}
				}

			}
			else
			{
				// Special bookmark __phpXplorer => all shares
				if ($sBookmark == '__phpXplorer')
				{
					$oQuery = new pxQuery();
					$oQuery->sDirectory = $pxp->sDir . '/shares';
					$oQuery->aTypes = array('pxShare');
					$aObjects = $pxp->oVfs->ls($oQuery);

					foreach ($aObjects as $oShare)
					{
						$sShare = $oShare->sId;

						if ($sShare == '_pxUserHomePrototype') {
							continue;
						}

						$oShare =& $pxp->oVfs->get_object(
							$pxp->sDir . '/shares/' . $sShare . '.pxShare',
							false
						);
						

						if (!empty($oShare->sTitle)) {
							$this->_aBookmarks[$sShare] = $oShare->sTitle;
						} else {
							$this->_aBookmarks[$sShare] = $sShare;
						}

						if ($sShare == $pxp->sShare or $bFirst) {
							$this->_sDefaultBookmark = $sShare;
							$bFirst = false;
						}
					}
				}
				else
				{
					// Normal share
					$oShare =& $pxp->oVfs->get_object(
						$pxp->sDir . '/shares/' . $sBookmark . '.pxShare',
						false,
						false
					);

					if (!empty($oShare)) {

						if (!empty($oShare->sTitle)) {
							$this->_aBookmarks[$sBookmark] = $oShare->sTitle;
						} else {
							$this->_aBookmarks[$sBookmark] = $sBookmark;
						}

						if ($oShare->sId == $pxp->sShare or $bFirst) {
							$this->_sDefaultBookmark = $oShare->sId;
							$bFirst = false;
						}
					}
					
				}
			}
		}

		if (count($this->_aBookmarks) < 1) {
			$pxp->raiseError('noBookmarks', __FILE__, __LINE__);
		}

		$oProfile = $pxp->getObject(
			'phpXplorer://profiles/' . $pxp->sUser . '.pxProfile',
			false,
			true
		);

		if (!empty($oProfile->sFullName)) {
			$sName = $oProfile->sFullName;
		} else {
			$sName = $pxp->sUser;
		}

		$bUpload = ini_get('file_uploads');

		$this->sendJson(
			array(
				'bDebug' => $pxp->aConfig['bDebug'],
				'bDevelopment' => $pxp->aConfig['bDevelopment'],
				'sTitle' => $pxp->aConfig['sTitle'],
				'sTitleLink' => $pxp->aConfig['sTitleLink'],
				'sSubTitle' => $pxp->aConfig['sSubTitle'],
				'bContact' => $pxp->aConfig['bContact'],
				'aBookmarks' => $this->_aBookmarks,
				'sUser' => $pxp->sUser,
				'sUserLanguage' => $pxp->sLanguage,
				'sSystemLanguage' => $pxp->aConfig['sSystemLanguage'],
				'sDefaultBookmark' => $pxp->sShare,
				'oProfile' => $oProfile,
				'bUpload' => !empty($bUpload),
				'aGdExtensions' => $pxp->aConfig['aGdExtensions'],
				'aImageMagickExtensions' => $pxp->aConfig['aImageMagickExtensions'],
				'sLogoUrl' => $pxp->aConfig['sLogoUrl']
			)
		);
	}
}

?>