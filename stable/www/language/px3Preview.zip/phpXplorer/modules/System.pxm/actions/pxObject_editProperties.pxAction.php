<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/../actions/pxObject__editProperty.pxAction.php';

class pxObject_editProperties extends pxAction
{
	/**
	 * Array of object properties
	 * 
	 * @access protected
	 * @var array Array of pxProperty objects
	 */
	var $aProperties = array();

	/**
	 * Main method to start execution of action
	 */
	function run()
	{
		global $pxp;
		
		$pxp->loadType('pxProperty');

		$this->aProperties = $pxp->aTypes[$pxp->oObject->sType]->getAllProperties();

#echo $pxp->oObject->sType;

		if (!empty($pxp->_POST))
		{
			$aErrors = array();

			foreach ($this->aProperties as $sId => $oProperty) {
				pxObject__editProperty::setProperty(
					$oProperty,
					$aErrors
				);
			}

			$this->storeObject($aErrors);
		}
	}
}

?>