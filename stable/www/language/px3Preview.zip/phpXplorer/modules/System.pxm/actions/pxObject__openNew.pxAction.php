<?php
/* Copyright notice */

/**
 * Class for object creation
 */
class pxObject__openNew extends pxAction
{
	/**
	 *
	 */
	function run(&$oObject, $aParameters = null, $bCreate = true)
	{
		global $pxp;

		if ($pxp->_GET) {
			$aTypeOptions = array();
			$aTypeOptions[$pxp->oObject->sType] = array();
			$aProperties = $pxp->aTypes[$pxp->oObject->sType]->getAllProperties();
			foreach ($aProperties as $oProperty) {
				$aOptions = $pxp->oObject->_getOptions($oProperty->sId);
				if (isset($aOptions)) {
					$aTypeOptions[$pxp->oObject->sType][$oProperty->sId] = $aOptions;
				}
			}

			$this->sendJson(
				array(
					'sDirectory' => pxUtil::buildPath($pxp->sShare . ':/', $pxp->sRelPathIn),				
					'mResult' => array(&$pxp->oObject),
					'oSettings' => array(
						'sDirectoryType' => $pxp->oObject->sType,
						'oOptions' => $aTypeOptions
					)
				)
			);
		}
	}
}
?>