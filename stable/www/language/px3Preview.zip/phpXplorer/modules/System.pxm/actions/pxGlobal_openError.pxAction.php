<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxGlobal___htmlDoc.pxAction.php';

/**
 * Show phpXplorer error message.
 */
class pxGlobal_openError extends pxGlobal___htmlDoc
{
	var $_aInfos = array();

	function pxGlobal_openError() {
		parent::pxGlobal___htmlDoc(false);
	}

	/**
	 * 
	 */
	function run($oObject, $aParameters)
	{
		global $pxp;

		$bJson = true;
		if (function_exists('getallheaders')) {
			$aHeaders = getallheaders();
			if (!isset($aHeaders['X-Requested-With']) || $aHeaders['X-Requested-With'] != 'XMLHttpRequest') {
				$bJson = false;
			}
		}

		$this->_aInfos = array(
			'bError' => true,
			'sId' => $aParameters['sId']
		);

		if ($pxp->aConfig['bDebug']) {
			$this->_aInfos['sVersion'] = $pxp->aConfig['sVersion'];
			$this->_aInfos['sFileIn'] = $aParameters['sFileIn'];
			$this->_aInfos['sLine'] = $aParameters['sLine'];
			$this->_aInfos['aValues'] = $aParameters['aValues'];
		}

		if ($bJson) {
			$this->sendJson($this->_aInfos);
			die;
		} else {
			$pxp->loadTranslation();
			parent::run();
			die;
		}
	}

	function buildBody()
	{
		global $pxp;

		$sMessage = $pxp->aTranslation['error.' . $this->_aInfos['sId']];
		
		if (is_array($this->_aInfos['aValues'])) {
			foreach ($this->_aInfos['aValues'] as $sValue) {
				$sMessage = pxUtil::str_replace_once('%s', $sValue, $sMessage);
			}
		}
		$sMessage = trim(str_replace('%s', '', $sMessage));

		$sLocation = $pxp->aTranslation['error'];
		if ($pxp->aConfig['bDebug']) {
			$sLocation .= ' in <b>' . $this->_aInfos['sFileIn'] . '</b> on line <b>' . $this->_aInfos['sLine'] . '</b>';
		}
		
		$sFoot = 'phpXplorer';
		if ($pxp->aConfig['bDebug']) {
			$sFoot .= ' ' . $pxp->aConfig['sVersion'];
		}
		$sFoot .= ' at ' . $_SERVER['HTTP_HOST'];

		$sHtml =
			'<h1>' . $sMessage . '</h1>' .
			'<p>' . $sLocation . '</p>' .
			'<hr/>' .
			'<address>' . $sFoot . '</address>' 
		;

		$this->sBody .= $sHtml;
		
	}
	
}

?>
