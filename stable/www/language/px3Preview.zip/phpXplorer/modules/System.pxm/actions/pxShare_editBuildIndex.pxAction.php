<?php
/* Copyright notice */

class pxShare_editBuildIndex extends pxAction
{
	function run()
	{
		global $pxp;

		$pxp->oObject->init();
		$this->sMimeType = 'text/plain';
		$this->sendHeaders();

		$pxp->loadShare($pxp->oObject->sId);
		$pxp->aShares[$pxp->oObject->sId]->oVfs->buildFSIndex($pxp->oObject->sBaseDir, true);
	}
}

?>