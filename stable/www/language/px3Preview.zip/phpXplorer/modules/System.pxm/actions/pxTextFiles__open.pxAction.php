<?php
/* Copyright notice */

class pxTextFiles__open extends pxAction
{
	/**
	 * 
	 */
	function run()
	{
		global $pxp;

		$this->sendJson(
			array(
				'sDirectory' => pxUtil::buildPath($pxp->sShare . ':', $pxp->sRelPathIn),
				'mResult' => $pxp->oShare->oVfs->file_get_contents($pxp->sFullPathIn)
			)
		);
	}
}
?>