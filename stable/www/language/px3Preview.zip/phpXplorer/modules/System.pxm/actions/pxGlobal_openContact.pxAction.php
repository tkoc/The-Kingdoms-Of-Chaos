<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxGlobal___htmlDoc.pxAction.php';

class pxGlobal_openContact extends pxGlobal___htmlDoc
{
	/**
	 *
	 */
	function pxGlobal_openContact($aUserInfo = null)
	{
		global $pxp;

		parent::pxGlobal___htmlDoc(false);

		$this->addStyle('modules/System.pxm/doc.css');

		#$this->addScript('modules/System.pxm/frontend/px/action/pxGlobal_openLoginForm.js');

		#$this->addScriptCode('pxp.bStop = true;');

		$this->setForm($pxp->_SERVER['PHP_SELF'] . '?' . $pxp->_SERVER['QUERY_STRING']);
		$this->sHtmlId = 'contact';

		$pxp->loadTranslation();

		$sHtml =
			'<div class="contentFrame">' .
			'<h2>' . $pxp->aConfig['aContact']['sOrganisation'] . '</h2>'
		;
		
		$aGroups = array();
		$sActiveGroup = '';

		foreach ($pxp->aConfig['aContact'] as $sKey => $sItem) {			
			if (!empty($sItem)) {
				if (isset($pxp->aTranslation['contact.' . $sKey])) {
					$sActiveGroup = $sKey;
				}
				$aGroups[$sActiveGroup][] = pxUtil::translateTitle($sItem);
			}
		}

		foreach ($aGroups as $sGroup => $aItems) {
			if (!empty($sGroup)) {
				$sHtml .= '<h3>' . $pxp->aTranslation['contact.' . $sGroup] . '</h3><p>';
			}
			foreach ($aItems as $sItem) {
				$sHtml .= $sItem . '<br/>';
			}
			$sHtml .= '</p>';
		}

		$sHtml .=
			'<br/>' .
			'<h2 class="sub">Nachricht</h2>' .
			'<p>' .
			'<textarea name="message" id="message" rows="8" cols="24"></textarea>' .
			'<input type="text" name="email" id="email" />' .
			'<button type="submit" id="submit">' .
			'<div>' . $pxp->aTranslation['send'] . '</div>' .
			'</button>' .
			'</p>' .
			'</div>'
		;		
		

		$this->sBody .= $sHtml;
	}
}


?>