<?php
/* Copyright notice */

class pxGlobal_openCreate extends pxAction
{
	/**
	 *
	 */
	function run()
	{
		global $pxp;

		$aTypes = array();

		foreach ($pxp->aTypes as $sKey => $oType) {
			if ($oType->bCreate) {
				if ($pxp->oShare->checkCreatePermission($pxp->sRelDir, $sKey)) {
					$aTypes[] = $sKey;
				}
			}
		}

		$this->sendJson($aTypes);
	}
}

?>
