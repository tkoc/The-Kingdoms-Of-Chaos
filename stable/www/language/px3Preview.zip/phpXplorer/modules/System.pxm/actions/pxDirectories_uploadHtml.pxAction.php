<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxDirectories___upload.pxAction.php';

class pxDirectories_uploadHtml extends pxDirectories___upload
{
	/**
	 *
	 */
	function pxDirectories_uploadHtml() {
		global $pxp;
		parent::pxDirectories___upload();
	}

	/**
	 * 
	 */
	function buildBody() {
		global $pxp;

		$sHtml = '';

		parent::buildBody();

		$sHtml .=
			'<p>' .
			$pxp->aTranslation['upload.targetDirectory'] . ': &raquo;' . pxUtil::buildPath($pxp->sShare . ':/' , $pxp->decodeURI($pxp->_GET['sPath'])) . '&laquo;<br/><br/>' .
			'<span id="file_attach" style="padding:0">' .
				'<input size="30" type="file" class="upload" name="aFiles[]" onchange="px.action.pxDirectories_uploadHtml.attachFile(this)" id="file_input" />' .
			'</span>' .
			'<select name="aFileSelection" multiple="multiple" id="aFileSelection" size="8" style="width:92%;margin-top:0.3em"></select><br/>' .
			'<button style="margin-top:0.3em" onclick="px.action.pxDirectories_uploadHtml.removeSelectedFile()" class="action" name="remove">' .
				$pxp->aTranslation['upload.removeSelection'] .
			'</button>' .
			'</p>' .
			'<p>' .
			'<label for="overwrite">' . $pxp->aTranslation['upload.overwriteFiles'] . '</label> ' .
			'<input type="checkbox" name="bOverwrite" value="true" id="overwrite" />' .
			'<br/>' .
			'<button style="margin-top:0.3em" id="submitButton" onclick="if($(\'aFileSelection\').options.length > 0)document.forms[0].submit()" disabled="disabled">' . $pxp->aTranslation['upload.upload'] . '</button>' .
			'</p>'
			;
		$this->sBody .= $sHtml;
	}
}
?>