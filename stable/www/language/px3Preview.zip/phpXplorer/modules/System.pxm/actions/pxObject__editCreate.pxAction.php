<?php
/* Copyright notice */

class pxObject__editCreate extends pxAction {}

?>