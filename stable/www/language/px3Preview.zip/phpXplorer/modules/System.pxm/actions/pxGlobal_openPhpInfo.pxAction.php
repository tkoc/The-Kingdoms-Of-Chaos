<?php
/* Copyright notice */

/**
 * Show PHP info page to administrative users.
 */
class pxGlobal_openPhpInfo extends pxAction
{
	/**
	 * 
	 */
	function run()
	{
		global $pxp;

		$oSettings = $pxp->oShare->getSettings($pxp->sRelPathIn, $pxp->sUser);

		if (in_array('pxAdministrator', $oSettings->aRoles)) {
			phpInfo();
		} else {
			$pxp->raiseError('accessDenied', __FILE__, __LINE__);
		}
	}
}

?>
