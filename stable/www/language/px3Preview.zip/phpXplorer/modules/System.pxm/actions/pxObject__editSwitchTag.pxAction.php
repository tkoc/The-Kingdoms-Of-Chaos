<?php
/* Copyright notice */

class pxObject__editSwitchTag extends pxAction
{
	/**
	 * 
	 */
	var $sTag;

	/**
	 * 
	 */
	function pxObject__editSwitchTag()
	{
		global $pxp;

		$this->sTag = $pxp->getRequestVar('sTag');
		parent::pxAction();
	}

	/**
	 * Main method to start execution of action
	 */
	function run()
	{
		global $pxp;

		if ($pxp->_POST && !empty($this->sTag)) {
			if (in_array($this->sTag, $pxp->oObject->aTags)) {
				$pxp->oObject->aTags = array_diff($pxp->oObject->aTags, array($this->sTag));
			} else {
				$pxp->oObject->aTags[] = $this->sTag;
			}
			$pxp->oObject->store();
		}
	}
}

?>