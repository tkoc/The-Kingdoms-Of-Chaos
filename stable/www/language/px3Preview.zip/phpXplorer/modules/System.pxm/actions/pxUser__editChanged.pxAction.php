<?php
/* Copyright notice */

/**
 * Create bookmark files and add bookmarks to user profile
 */
class pxUser__editChanged extends pxAction
{
	/**
	 *
	 */
	function run(&$oObject, $aParameters = null)
	{
		global $pxp;

		$oObject->_bCancelBubble = true;

		$sAction = $aParameters['sTriggeringAction'];

		if ($sAction != 'editProperties') {
			return true;
		}

		$sShare = $pxp->oShare->sId;
		$sBookmarkDir = pxUtil::dirname(pxUtil::dirname($pxp->sRelPathIn));
		$bInSystem = $sShare == 'phpXplorer';
		$bInShares = $bInSystem && $sBookmarkDir == '/shares';

		if (!$bInSystem && !$bInShares)
		{
			$sBookmarkId = 'px' . md5($pxp->aConfig['sId'] . $sShare . $sBookmarkDir);
			$sBookmarkFile = $pxp->sDir . '/bookmarks/' . $sBookmarkId;

			if (!$pxp->oVfs->file_exists($sBookmarkFile)) {
				$pxp->oVfs->file_put_contents(
					$sBookmarkFile,
					$sShare . '|' . $sBookmarkDir
				);
			}
		}

		// Add bookmark to user profile
		$sUserId = substr($pxp->oObject->sName, 0, strpos($pxp->oObject->sName, '.'));
		$sProfilePath = 'phpXplorer://profiles/' . $sUserId . '.pxProfile';
		$oProfile = $pxp->getObject($sProfilePath, false, false);

		if (!isset($oProfile)) {
			# check if user exists
			$pxp->loadType('pxProfile');
			$oProfile = new pxProfile();
			$oProfile->sOwner = $sUserId;
		}

		if ($bInSystem && !$bInShares) {
			$sProfileBookmark = '__phpXplorer';
		} else {
			if ($bInShares) {
				$sShareName = basename(pxUtil::dirname($pxp->sRelPathIn));
				$sShareId = str_replace('.pxShare', '', $sShareName);
				$sProfileBookmark = $sShareId;
			} else {
			// 	Add the bookmark ID of the current folder
				$sProfileBookmark = $sBookmarkId;
			}
		}

		if (!in_array($sProfileBookmark, $oProfile->aBookmarks)) {
			$oProfile->aBookmarks[] = $sProfileBookmark;
			$oProfile->store($sProfilePath);
		}
	}
}
?>