<?php
/* Copyright notice */

/**
 * Show phpXplorer info/about screen.
 */
class pxGlobal_sendMail extends pxAction
{
	/**
	 * 
	 */
	var $_aParameters = array();

	/**
	 * 
	 */
	function run(&$oObject, $aParameters)
	{
		global $pxp;

		die;

		$this->_aParameters =& $aParameters;

		if (!isset($aParameters)) {
			$pxp->raiseError('invalidParameter', __FILE__, __LINE__);
		}

		$sFrom = implode(', ', $this->_getParameterArray('from'));
		$sTo = implode(', ', $this->_getParameterArray('to'));
		$sCc = implode(', ', $this->_getParameterArray('cc'));
		$sBcc = implode(', ', $this->_getParameterArray('bcc'));
		$sSubject = isset($aParameters['subject']) ? $aParameters['subject'] : '';
		$sText = isset($aParameters['text']) ? $aParameters['text'] : '';
		$sHtml = isset($aParameters['html']) ? $aParameters['html'] : '';
		$aAttachments = $this->_getParameterArray('attach');

		if (empty($sTo)) {
			$pxp->raiseError('noReceiver', __FILE__, __LINE__);
		}
		
		$aHeaders = array();

		$aHeaders[] = 'MIME-Version: 1.0' . $sSubject;
		$aHeaders[] = 'Subject: ' . $sSubject;
		$aHeaders[] = 'From: ' . $sFrom;
		$aHeaders[] = 'Return-Path: ' . $sFrom;
		$aHeaders[] = 'To: ' . $sTo;
		if (!empty($sCc)) {
			$aHeaders[] = 'Cc: ' . $sCc;
		}
		if (!empty($sBcc)) {
			$aHeaders[] = 'Bcc: ' . $sBcc;
		}
		$aHeaders[] = 'Content-type: text/plain; charset=' . $pxp->aConfig['sEncoding'];
		$aHeaders[] = 'Content-Transfer-Encoding: 7bit';

		mail(
			$sTo,
			$sSubject,
			$sText,
			implode("\r\n", $aHeaders)
		);
	}
	
	/**
	 * 
	 */
	function _getParameterArray($sKey)
	{
		$aResult = array();

		if (isset($this->_aParameters[$sKey])) {
			$sParameter = $this->_aParameters[$sKey];
			$sParameter = str_replace("\r", null, $sParameter);
			$aLines = explode("\n", $sParameter);

			foreach ($aLines as $iIndex => $sLine) {

				$sAddress = trim($sLine);

				if (!empty($sAddress)) {

					if (strpos($sAddress, '(') !== false) {
						$sAddress = str_replace('(', '<', $sAddress);
						$sAddress = str_replace(')', '>', $sAddress);
					}

					$aResult[] = $sAddress;
				}
			}
		}
		return $aResult;
	}
}

?>
