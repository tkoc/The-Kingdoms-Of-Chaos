<?php
/* Copyright notice */

class pxObject__openOptions extends pxAction
{
	var $_sProperty;

	/**
	 *
	 */
	function pxObject__openOptions() {
		global $pxp;
		
		$this->_sProperty = $pxp->getRequestVar('sProperty');
		parent::pxAction();
	}

	function run($oObject, $aParameters = null) {
		global $pxp;
		
		if (!empty($this->_sProperty)) {
			$this->sendJson(
				$pxp->oObject->_getOptions(
					$this->_sProperty,
					true
				)
			);
		} else {
			$this->sendJson(array());
		}
	}
}
?>