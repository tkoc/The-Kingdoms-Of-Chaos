<?php
/* Copyright notice */

/**
 * Serialize fileset to JSON
 */
class pxObject__openJson extends pxAction
{
	function run($oObject, $aParameters = null) {
		global $pxp;
		$this->sendRequestQueryResultAsJson($pxp->getRequestVar('bFile') == 'true');
	}
}
?>