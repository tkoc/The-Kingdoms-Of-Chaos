<?php
/* Copyright notice */

/**
 * Class for HTML login form 
 */
class pxGlobal_openLogout extends pxAction
{
	/**
	 * 
	 */
	function pxGlobal_openLogout()
	{
		global $pxp;

		if (!empty($pxp->sUser) && $pxp->sUser != 'everyone') {
			$oProfile = $pxp->getObject('phpXplorer://profiles/' . $pxp->sUser . '.pxProfile', false);
			$oProfile->iLastLogout = time();
			$oProfile->store();
		}

		if ($pxp->_SESSION['pxp_bAuth']) {
			unset($pxp->_SESSION['pxp_bLogin']);
		}

		if (isset($pxp->_SESSION['pxp_sUser'])) {
			unset($pxp->_SESSION['pxp_sUser']);
		}

		session_write_close();

		if (!empty($pxp->aConfig['sAuthentication'])) {
			$pxp->oAuthentication = $pxp->getObject($pxp->aConfig['sAuthentication'], false);
			if ($pxp->oAuthentication->iLogin == 1 && empty($pxp->_SESSION['pxp_bLogin'])) {
				header('WWW-Authenticate: Basic realm="phpXplorer@' . $pxp->_SERVER['HTTP_HOST'] . '"');
				header('HTTP/1.0 401 Unauthorized');
				exit;
			}
		}


		$sLocation = $pxp->sUrl;
		if (strpos($sLocation, '?') === false) {
			$sLocation .= '?';	
		}
		$sLocation .= '&bForceLogin=true';

		header('Location: ' . $sLocation);

		exit;
	}
}

?>