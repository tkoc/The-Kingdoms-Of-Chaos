<?php
/* Copyright notice */

class pxDirectories__editDeleteSelection extends pxAction
{
	function run()
	{
		global $pxp;

		$this->bImplementsEventHandling = true;

		if (!$pxp->oShare->oVfs->is_dir($pxp->sFullPathIn)) {
			$pxp->raiseError('invalidParameter', __FILE__, __LINE__);
		}

		$oQuery = new pxQuery();
		$oQuery->sDirectory = $pxp->sFullPathIn;
		$oQuery->bRecursive = true;
		$oQuery->bPermissionCheck = false;
		$this->getFileSelection($oQuery->aNames);
		$aObjects = $pxp->oShare->oVfs->ls($oQuery);

		$aBookmarksToDelete = array();
		$this->deleteCheck($aObjects, $aBookmarksToDelete);
		
		$aFailedObjects = array();

		foreach ($aObjects as $oObject) {

			$sDir = $pxp->sFullPathIn;

			$sPath = pxUtil::buildPath(
				$sDir,
				$oObject->sName
			);

			if (
				strpos(realpath($sPath), 'D:\htdocs\phpXplorer\test') === false
				&& $pxp->sShare != 'ftp' && $pxp->sShare != 'Authentication' && $pxp->sShare != 'Demo' && $pxp->sShare != 'fontXplorer'
			) {
				die('STOP: ' . $sPath);
			}

			if ($oObject->bDirectory) {

				if (!$pxp->oShare->oVfs->rmdir($sPath)) {					
					$aFailedObjects[] = $oObject->sName;
					continue;
				}
			} else {
				if (!$pxp->oShare->oVfs->unlink($sPath)) {
					$aFailedObjects[] = $oObject->sName;
					continue;
				}
			}

			$oObject->triggerEvents('pxObject_editDelete');
		}

		foreach ($aBookmarksToDelete as $sFullPath => $aInfo) {
			if (!$pxp->oShare->oVfs->file_exists($sFullPath)) {
				$oProfile = $pxp->getObject('phpXplorer://profiles/' . $aInfo['sUser'] . '.pxProfile', false, false);
				if (isset($oProfile)) {
					$oProfile->aBookmarks = array_diff($oProfile->aBookmarks, array($aInfo['sBookmark']));
					$oProfile->store();
				}
				$pxp->oVfs->unlink($pxp->sDir . '/bookmarks/' . $aInfo['sBookmark']);
			}
		}

		if (!empty($aFailedObjects)) {
			
			#print_r($aFailedObjects);

			$pxp->raiseError('selectionAction', __FILE__, __LINE__, $aFailedObjects);	
		}
	}
}
?>