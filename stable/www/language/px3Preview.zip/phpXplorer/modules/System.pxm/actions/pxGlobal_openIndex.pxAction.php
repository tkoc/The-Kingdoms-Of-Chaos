<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxGlobal___htmlDoc.pxAction.php';

class pxGlobal_openIndex extends pxGlobal___htmlDoc
{
	/**
	 *
	 */
	function buildBody()
	{
		global $pxp;

		$pxp->loadTranslation();

		$this->sBody =
			'<div id="mainBar" class="mainBar pxBar"></div>' .
			'<div id="main"></div>' .
			'<img src="' . $pxp->sModuleUrl . '/System.pxm/graphics/loading.gif" id="loading" alt="" style="display:none" />' .
			'<div id="overlay" style="display:none"></div>' .
			'<div id="lightbox" style="display:none">' .
				'<img src="' . $pxp->sModuleUrl . '/System.pxm/graphics/dummy.png" alt="" />' .
				'<a href="#" id="previousImage" style="visibility:hidden"><img src="' . $pxp->sModuleUrl . '/System.pxm/graphics/previousImage.png" alt="" /></a>' .
				'<a href="#" id="nextImage" style="visibility:hidden"><img src="' . $pxp->sModuleUrl . '/System.pxm/graphics/nextImage.png" alt="" /></a>' .
			'</div>' .
			'<div id="infoBox" style="display:none">';
				if ($pxp->aConfig['bDebug']) {
					$this->sBody .=
						'<div class="infoBoxPane" id="debugPane" title="Debug">' .
							'PHP runtime: <span id="phpRuntime"></span><br/><br/>' .
							'<textarea rows="14" cols="76" id="debugLog"></textarea>' .
							'<br/><br/>' .
							'<button id="unloadButton">unload</button>&nbsp;' .
							'<button id="phpInfoButton">' . $pxp->aTranslation['action.pxGlobal_openPhpInfo'] . '</button>&nbsp;' .
						'</div>';
				}
		$this->sBody .= '</div>';
	}
}

?>