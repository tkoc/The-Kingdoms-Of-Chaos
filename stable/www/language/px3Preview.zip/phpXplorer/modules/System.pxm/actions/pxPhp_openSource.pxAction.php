<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxGlobal___htmlDoc.pxAction.php';

class pxPhp_openSource extends pxGlobal___htmlDoc
{
	/**
	 * 
	 */
	function pxPhp_openSource()
	{
		global $pxp;

		parent::pxGlobal___htmlDoc(false);

		$this->addStyleCode('body{white-space:nowrap}');

		$this->sBody .= $this->xhtml_highlight($pxp->oObject->getContents());		
	}

	/**
	 * 
	 */
	function xhtml_highlight($sPHP)
	{
		$sPHP = highlight_string($sPHP, true);
		$sPHP = str_replace(array('<font ', '</font>'), array('<span ', '</span>'), $sPHP);
		$sPXP = preg_replace('#color="(.*?)"#', 'style="color: \\1"', $sPHP);
		
		return $sPXP;
	}
}

?>