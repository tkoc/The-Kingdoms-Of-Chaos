<?php
/* Copyright notice */

class pxTextFiles_edit extends pxAction
{
	/**
	 * 
	 */
	function run() {
		global $pxp;

		if (!$pxp->oObject->setContents($pxp->getRequestVar('sContent'))) {
			$aErrors[] = 'couldNotWrite';
			$this->sendJson($aErrors);
		}
	}
}
?>