<?php
/* Copyright notice */

/**
 * Rename/delete user profile and user shares
 */
class pxVfsAuthenticationUser__editChanged extends pxAction
{
	/**
	 *
	 */
	function run(&$oObject, $aParameters = null)
	{
		global $pxp;

		$oObject->_bCancelBubble = true;

		$sAction = $aParameters['sTriggeringAction'];

		$sShare = $pxp->oShare->sId;
		
		$aNames = array();
		$this->getFileSelection($aNames, 'aNames', false);
		
		$aNewNames = array();
		$this->getFileSelection($aNewNames, 'aNewNames', false);

		switch ($sAction)
		{
			case 'editRename':

				$sMode = $pxp->getRequestVar('sMode');
				if ($sMode == 'move') {

					for ($i=0,$l=count($aNames); $i<$l; $i++) {
					{
						$sName = $aNames[$i];
						$sNewName = $aNewNames[$i];

						$oProfile = $pxp->getObject(
							'phpXplorer://profiles/' . $sName . '.pxProfile',
							false,
							false
						);

						if (isset($oProfile)) {
							
							$sDir = pxUtil::buildPath($pxp->sDir, 'profiles');
							$pxp->oVfs->rename(
								$sDir . '/' . $sName . '.pxProfile',
								$sDir . '/' . $sNewName . '.pxProfile'
							);

							foreach ($oProfile->aBookmarks as $sBookmark)
							{
								if (strpos($sBookmark, 'px') === 0 && strlen($sBookmark) == 34)
								{
									$sContent = $pxp->oVfs->file_get_contents($pxp->sDir . '/bookmarks/' . $sBookmark);
									$aParts = explode('|', $sContent);
									$sShare = $aParts[0];
									$pxp->loadShare($sShare);
									
									$sDir = pxUtil::buildPath($pxp->aShares[$sShare]->sBaseDir, $aParts[1]);
									$sDir = pxUtil::buildPath($sDir, '.phpXplorer');
									
									$pxp->aShares[$sShare]->oVfs->rename(
										$sDir . '/' . $sName . '.pxUser',
										$sDir . '/' . $sNewName . '.pxUser'
									);
								}
							}
						}
					}
				}
			}

			break;

			case 'editDelete':

				for ($i=0,$l=count($aNames); $i<$l; $i++)
				{				
					$sName = $aNames[$i];

					$oProfile = $pxp->getObject(
						'phpXplorer://profiles/' . $sName . '.pxProfile',
						false,
						false
					);

					if (isset($oProfile)) {

						$sDir = pxUtil::buildPath($pxp->sDir, 'profiles');

						$pxp->oVfs->unlink($sDir . '/' . $sName . '.pxProfile');

						foreach ($oProfile->aBookmarks as $sBookmark)
						{
							if (strpos($sBookmark, 'px') === 0 && strlen($sBookmark) == 34)
							{
								$sContent = $pxp->oVfs->file_get_contents($pxp->sDir . '/bookmarks/' . $sBookmark);
								$aParts = explode('|', $sContent);
								$sShare = $aParts[0];
								$pxp->loadShare($sShare);

								$sDir = pxUtil::buildPath($pxp->aShares[$sShare]->sBaseDir, $aParts[1]);
								$sDir = pxUtil::buildPath($sDir, '.phpXplorer');

								$pxp->aShares[$sShare]->oVfs->unlink($sDir . '/' . $sName . '.pxUser');
							}
						}
					}
				}
			break;
		}

	}
}
?>