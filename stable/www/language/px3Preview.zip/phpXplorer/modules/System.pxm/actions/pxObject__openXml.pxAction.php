<?php
/* Copyright notice */

/**
 * Serialize fileset to XML
 */
class pxObject__openXml extends pxAction
{
	/**
	 * 
	 */
	function pxObject__openXml()
	{
		global $pxp;
		
		$this->sMimeType = 'application/xml';

		parent::pxAction();
	}
	
	/**
	 * 
	 */
	function _buildXml($aObjects)
	{
		$sXml = '<aObjects>';

		foreach ($aObjects as $oObject) {
			
			if (
				!in_array(
					$oObject->sName,
					array(
						'.phpXplorer',
						'.thumbnails',
						'.htpasswd'
					))) {

				$sXml .= $oObject->serializeToXml();

				if (!empty($oObject->aObjects))  {
					$sXml .= $this->_buildXml($oObject->aObjects);
				}
			}
		}

		return $sXml . '</aObjects>';
	}
	
	function run($oObject, $aParameters = null)
	{
		global $pxp;
		
		parent::run();

		$this->aObjects = $pxp->oShare->oVfs->ls(
			$this->getRequestQuery(true)
		);		

		$sXml =
			'<?xml version="1.0" encoding="' . $pxp->aConfig['sEncoding'] . '"?>' .
			$this->_buildXml($this->aObjects);
		
		if (isset($aParameters) and isset($aParameters['bReturn'])) {
			return $sXml;
		}

		echo $sXml;
	}
}
?>