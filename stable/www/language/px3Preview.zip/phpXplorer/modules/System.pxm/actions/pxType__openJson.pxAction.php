<?php
/* Copyright notice */

/**
 * Serialize fileset to JSON
 */
class pxType__openJson extends pxAction
{
	function run($oObject, $aParameters = null) {
		global $pxp;
		
		#$pxp->oObject->sShare = 'phpXplorer';
		#$pxp->oObject->sPa
		
		$this->sendRequestQueryResultAsJson(true);
	}

	function _handleQueryResult(&$aObjects) {

		$oObject =& $aObjects[0];
		
		$sType = $oObject->sId;
		
		echo $sType;
		die;
				
	}
}
?>