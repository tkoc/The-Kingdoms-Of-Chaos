<?php
/* Copyright notice */

/**
 * Download file
 */
class pxMetaFiles_openDownload extends pxAction
{
	/**
	 * 
	 */
	function run() {
		global $pxp;

		foreach ($pxp->aTypes[$pxp->oObject->sType]->aExtensions as $iIndex => $sExtension) {
			if ($sExtension == $pxp->oObject->sExtension) {
				$this->sMimeType = $pxp->aTypes[$pxp->oObject->sType]->aMimeTypes[$iIndex];
				break;
			}
		}

		$this->sendHeaders();

		@ini_set('zlib.output_compression', 'Off');

		header('Cache-Control: public', true);
   	header('Content-Disposition: attachment; filename="' . $pxp->oObject->sName . '"');
   	header('Content-Length: ' . $pxp->oObject->iBytes);
   	echo $pxp->oObject->getContents();
	}
}

?>