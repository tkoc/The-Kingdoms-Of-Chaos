<?php
/* Copyright notice */

class pxGlobal_openShare extends pxAction
{
	function run()
	{
		global $pxp;

		$pxp->oShare->oVfs = null;
		$this->sendJson($pxp->oShare);
	}
}

?>