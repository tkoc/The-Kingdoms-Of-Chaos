<?php
/* Copyright notice */

require_once dirname(__FILE__) . '/pxGlobal___htmlDoc.pxAction.php';

/**
 * HTML login form 
 */
class pxGlobal_openLogin extends pxGlobal___htmlDoc
{
	/**
	 *
	 */
	function pxGlobal_openLogin($aUserInfo = null)
	{
		global $pxp;

		parent::pxGlobal___htmlDoc();

		$this->addScript('modules/System.pxm/frontend/px/action/pxGlobal_openLogin.js');
		$this->addScript('modules/System.pxm/frontend/px/action/pxGlobal_openLoginForm.js');

		$this->addScriptCode('pxp.bStop = true;');

		$this->setForm($pxp->_SERVER['PHP_SELF'] . '?' . $pxp->_SERVER['QUERY_STRING']);

		$this->sBody .=
			'<table id="loginTable">' .
			'<tr>' .
				'<td>' .
					'<table><tr><td id="loginContainer"></td></tr></table>' .
				'</td>' .
			'</tr>' .
			'</table>';
	}
}


?>