<?php

class pxUtil
{
	function buildPath($sDir, $sFile) {
		if (!empty($sDir)) {
			if (substr($sFile, 0, 1) == '/') {
				$sFile = substr($sFile, 1);
			}
			if (!empty($sFile) && substr($sDir, -1) != '/') {
				return $sDir . '/' . $sFile;
			} else {
				return $sDir . $sFile;
			}
		} else {
			return $sFile;
		}
	}

	function dirname($sDir) {
		$sParentDir = dirname($sDir);
		if($sParentDir == "\\") {
			$sParentDir = '/';
		}
		return $sParentDir;
	}

	function str_replace_once($sNeedle, $sReplace, $sHaystack) {
		$iPos = strpos($sHaystack, $sNeedle);
		if($iPos === false) {
			return $sHaystack;
		}
   return substr_replace($sHaystack, $sReplace, $iPos, strlen($sNeedle));
	}

	function stripSlashesRecursive($mVariable) {
		if (is_array($mVariable)) {
			foreach ($mVariable as $index => $value) {
				$mVariable[$index] = pxUtil::stripSlashesRecursive($value);
			}
		} else {
			$mVariable = stripslashes($mVariable);
		}
		return $mVariable;
	}

	function getBaseAction($sAction)
	{
		$iActionPos = strpos($sAction, '_');
		if ($iActionPos !== false) {
			$iActionPos ++;
		} else {
			$iActionPos = 0;
		}
		if (strpos($sAction, '_', $iActionPos)) {
			$iActionPos ++;
		}
		for ($i = $iActionPos, $m = strlen($sAction); $i < $m; $i ++) {
			$iChar = ord(substr($sAction, $i, 1));
			
			if (($iChar >= 65 && $iChar <= 90)) {
				return substr($sAction, $iActionPos, $i - $iActionPos);
			}
		}
		return substr($sAction, $iActionPos);
	}

	function getArrayString($aArray)
	{
  	$sArray = 'array(';
  	foreach ($aArray as $mKey => $mValue) {
  		if (!is_numeric($mKey)) {
  			$sArray .= '\'' . $mKey . '\'=>';
  		}
  		if (is_array($mValue)) {
  			$sArray .= '' . pxUtil::getArrayString($mValue) . ',';
  		}
			else if (is_numeric($mValue)) {
  			
  		}
			else if (is_bool($mValue)) {
  			$sArray .= (int)$mValue . ',';
  		}
			else {
  			$sArray .= '\'' . $mValue . '\',';
  		}
  	}
		if (!empty($aArray)) {
			$sArray = substr($sArray, 0, strlen($sArray) - 1);
		}
		return $sArray . ')';			
	}

	function getMicrotime() {
		list($usec, $sec) = explode(' ', microtime());
		return ((float)$usec + (float)$sec);
	}

	function checkFilename($sName, $bPath = false) {
		$aInvalidChars = array(chr(92), ':', '*', '?', '<', '>', '|', '..');
		if (!$bPath) {
			$aInvalidChars[] = '/';
		} else {
			$aInvalidChars[] = '//';
		}
		for ($i = count($aInvalidChars) - 1; $i >= 0; $i--) {
			if (strpos($sName, $aInvalidChars[$i]) !== false) {
				return false;
			}
		}
		return true;
	}
	
	function translateTitle($sTitle)
	{
		global $pxp;

		if (strpos($sTitle, '~') === 0) {
			$sKey = substr($sTitle, 1);
			if (isset($pxp->aTranslation[$sKey])) {
				return $pxp->aTranslation[$sKey];
			}
		}
		return $sTitle;
	}
}

?>